import { useEffect, useRef, useState } from "react";
import { MapPin, Plus, Minus, Navigation } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

interface MapViewProps {
  center?: { lat: number; lng: number };
  zoom?: number;
  markers?: Array<{ lat: number; lng: number; type: string; label?: string }>;
  destination?: { lat: number; lng: number; name: string } | null;
  className?: string;
}

export function MapView({ center = { lat: 19.4326, lng: -99.1332 }, zoom = 12, markers = [], destination = null, className }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<mapboxgl.Map | null>(null);
  const userMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const destinationMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const markerInstancesRef = useRef<mapboxgl.Marker[]>([]);
  const [currentSpeed, setCurrentSpeed] = useState(0);
  const [speedLimit, setSpeedLimit] = useState(80);
  const [mapZoom, setMapZoom] = useState(zoom);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [estimatedTime, setEstimatedTime] = useState("--");
  const [distance, setDistance] = useState("--");
  const [mapError, setMapError] = useState<string | null>(null);

  useEffect(() => {
    const mapboxToken = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;
    
    if (mapboxToken && mapRef.current && !mapInstanceRef.current) {
      try {
        mapboxgl.accessToken = mapboxToken;
        
        // Initialize Mapbox GL JS
        const map = new mapboxgl.Map({
          container: mapRef.current,
          style: 'mapbox://styles/mapbox/dark-v11',
          center: [center.lng, center.lat],
          zoom: zoom,
          pitch: 0,
          bearing: 0
        });

        map.addControl(new mapboxgl.NavigationControl(), 'top-right');
        map.addControl(new mapboxgl.ScaleControl(), 'bottom-left');

        map.on('load', () => {
          setMapReady(true);
          console.log('✅ Mapbox map loaded successfully');
        });
        
        map.on('error', (e) => {
          console.error('Mapbox error:', e);
          setMapError('No se pudo cargar el mapa. WebGL no disponible.');
        });

        map.on('zoom', () => {
          setMapZoom(map.getZoom());
        });

        mapInstanceRef.current = map;
      } catch (error) {
        console.error('Error initializing Mapbox:', error);
        setMapError('No se pudo inicializar el mapa. WebGL no disponible.');
      }
    }

    // Track user location and speed
    if (navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const speed = position.coords.speed ? Math.round(position.coords.speed * 3.6) : 0;
          setCurrentSpeed(speed);
          
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          setUserLocation(newLocation);

          // Update user marker on map
          if (mapInstanceRef.current && mapReady) {
            if (!userMarkerRef.current) {
              const el = document.createElement('div');
              el.className = 'user-location-marker';
              el.style.width = '20px';
              el.style.height = '20px';
              el.style.borderRadius = '50%';
              el.style.backgroundColor = '#3b82f6';
              el.style.border = '3px solid white';
              el.style.boxShadow = '0 0 10px rgba(59, 130, 246, 0.5)';

              userMarkerRef.current = new mapboxgl.Marker({ element: el })
                .setLngLat([newLocation.lng, newLocation.lat])
                .addTo(mapInstanceRef.current);
            } else {
              userMarkerRef.current.setLngLat([newLocation.lng, newLocation.lat]);
            }
          }
        },
        (error) => {
          console.error('Geolocation error:', error);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );

      return () => {
        navigator.geolocation.clearWatch(watchId);
        if (mapInstanceRef.current) {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        }
      };
    }
  }, [mapReady]);

  // Update markers when markers prop changes
  useEffect(() => {
    if (!mapInstanceRef.current || !mapReady) return;

    // Remove old markers
    markerInstancesRef.current.forEach(marker => marker.remove());
    markerInstancesRef.current = [];

    // Add new markers
    markers.forEach((marker) => {
      const el = document.createElement('div');
      el.className = 'custom-marker';
      
      // Assign color based on marker type
      const markerColors: Record<string, string> = {
        report: '#ef4444', // red for reports
        gas_station: '#22c55e', // green
        restaurant: '#f59e0b', // orange
        hotel: '#3b82f6', // blue
        rest_area: '#8b5cf6', // purple
        mechanic: '#eab308', // yellow
      };
      
      const color = markerColors[marker.type] || '#6b7280'; // default gray
      
      el.style.width = '24px';
      el.style.height = '24px';
      el.style.borderRadius = '50%';
      el.style.backgroundColor = color;
      el.style.border = '2px solid white';
      el.style.boxShadow = `0 2px 8px ${color}44`;
      el.style.cursor = 'pointer';

      const mapMarker = new mapboxgl.Marker({ element: el })
        .setLngLat([marker.lng, marker.lat])
        .addTo(mapInstanceRef.current!);

      if (marker.label) {
        mapMarker.setPopup(new mapboxgl.Popup({ offset: 25 }).setText(marker.label));
      }

      markerInstancesRef.current.push(mapMarker);
    });

    return () => {
      markerInstancesRef.current.forEach(marker => marker.remove());
      markerInstancesRef.current = [];
    };
  }, [markers, mapReady]);

  // Update route when destination changes
  useEffect(() => {
    if (!mapInstanceRef.current || !mapReady || !destination || !userLocation) {
      // Remove destination marker and route if no destination
      if (destinationMarkerRef.current) {
        destinationMarkerRef.current.remove();
        destinationMarkerRef.current = null;
      }
      if (mapInstanceRef.current?.getLayer('route')) {
        mapInstanceRef.current.removeLayer('route');
        mapInstanceRef.current.removeSource('route');
      }
      setEstimatedTime("--");
      setDistance("--");
      return;
    }

    // Add destination marker
    if (!destinationMarkerRef.current) {
      const el = document.createElement('div');
      el.className = 'destination-marker';
      el.style.width = '32px';
      el.style.height = '32px';
      el.style.borderRadius = '50%';
      el.style.backgroundColor = '#ef4444';
      el.style.border = '4px solid white';
      el.style.boxShadow = '0 4px 12px rgba(239, 68, 68, 0.5)';

      destinationMarkerRef.current = new mapboxgl.Marker({ element: el })
        .setLngLat([destination.lng, destination.lat])
        .setPopup(new mapboxgl.Popup({ offset: 25 }).setText(destination.name))
        .addTo(mapInstanceRef.current);
    } else {
      destinationMarkerRef.current.setLngLat([destination.lng, destination.lat]);
    }

    // Calculate distance (straight line approximation)
    const R = 6371; // Earth radius in km
    const dLat = (destination.lat - userLocation.lat) * Math.PI / 180;
    const dLon = (destination.lng - userLocation.lng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(userLocation.lat * Math.PI / 180) * Math.cos(destination.lat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distanceKm = R * c;

    setDistance(`${distanceKm.toFixed(1)} km`);
    
    // Estimate time (assuming 60 km/h average)
    const timeHours = distanceKm / 60;
    const timeMinutes = Math.round(timeHours * 60);
    setEstimatedTime(timeMinutes < 60 ? `${timeMinutes} min` : `${Math.floor(timeMinutes / 60)}h ${timeMinutes % 60}m`);

    // Draw route line
    const routeGeoJSON = {
      type: 'Feature' as const,
      properties: {},
      geometry: {
        type: 'LineString' as const,
        coordinates: [
          [userLocation.lng, userLocation.lat],
          [destination.lng, destination.lat]
        ]
      }
    };

    if (mapInstanceRef.current.getLayer('route')) {
      mapInstanceRef.current.removeLayer('route');
      mapInstanceRef.current.removeSource('route');
    }

    mapInstanceRef.current.addSource('route', {
      type: 'geojson',
      data: routeGeoJSON
    });

    mapInstanceRef.current.addLayer({
      id: 'route',
      type: 'line',
      source: 'route',
      layout: {
        'line-join': 'round',
        'line-cap': 'round'
      },
      paint: {
        'line-color': '#fbbf24',
        'line-width': 5,
        'line-opacity': 0.9
      }
    });

    // Fit bounds to show both user and destination
    const bounds = new mapboxgl.LngLatBounds();
    bounds.extend([userLocation.lng, userLocation.lat]);
    bounds.extend([destination.lng, destination.lat]);
    mapInstanceRef.current.fitBounds(bounds, { padding: 100, duration: 1000 });

    return () => {
      if (destinationMarkerRef.current) {
        destinationMarkerRef.current.remove();
        destinationMarkerRef.current = null;
      }
      if (mapInstanceRef.current?.getLayer('route')) {
        mapInstanceRef.current.removeLayer('route');
        mapInstanceRef.current.removeSource('route');
      }
    };
  }, [destination, userLocation, mapReady]);

  const handleCenterLocation = () => {
    if (userLocation && mapInstanceRef.current) {
      mapInstanceRef.current.flyTo({
        center: [userLocation.lng, userLocation.lat],
        zoom: 15,
        duration: 1000
      });
    } else if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        setUserLocation(location);
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo({
            center: [location.lng, location.lat],
            zoom: 15,
            duration: 1000
          });
        }
      });
    }
  };

  return (
    <div className={className}>
      <div ref={mapRef} className="relative w-full h-[calc(100vh-4rem)] bg-[#1a1a2e] rounded-xl overflow-hidden">
        {/* Fallback message if Mapbox token is not available */}
        {!import.meta.env.VITE_MAPBOX_ACCESS_TOKEN && (
          <div className="absolute inset-0 flex items-center justify-center text-muted-foreground z-20 bg-[#1a1a2e]">
            <div className="text-center p-8">
              <MapPin className="w-16 h-16 mx-auto mb-4 text-primary" />
              <p className="text-lg font-semibold mb-2">Mapa de navegación</p>
              <p className="text-sm mb-4">Configura Mapbox para activar mapas reales:</p>
              <div className="bg-card/50 backdrop-blur-sm rounded-lg p-4 max-w-md mx-auto text-left">
                <p className="text-xs text-muted-foreground mb-2">Agregar credenciales:</p>
                <code className="text-xs block mb-1">VITE_MAPBOX_ACCESS_TOKEN</code>
              </div>
            </div>
          </div>
        )}
        
        {/* Fallback message if map initialization failed */}
        {mapError && (
          <div className="absolute inset-0 flex items-center justify-center text-muted-foreground z-20 bg-[#1a1a2e]">
            <div className="text-center p-8">
              <MapPin className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
              <p className="text-lg font-semibold mb-2">Mapa no disponible</p>
              <p className="text-sm mb-4">{mapError}</p>
              <p className="text-xs text-muted-foreground">La navegación continuará funcionando con datos GPS</p>
            </div>
          </div>
        )}

        <Button
          size="icon"
          variant="secondary"
          className="absolute bottom-32 right-8 rounded-full bg-black/70 backdrop-blur-sm hover:bg-black/80"
          onClick={handleCenterLocation}
          data-testid="button-center-location"
        >
          <Navigation className="w-5 h-5" />
        </Button>

        {/* Speed overlay */}
        <Card className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#2b2d42]/95 backdrop-blur-md border-none p-6 min-w-[300px]">
          <div className="flex items-center justify-between gap-8">
            <div className="text-center">
              <div className="text-xs text-muted-foreground mb-1">Velocidad Actual</div>
              <div className="text-4xl font-mono font-bold text-white">
                {currentSpeed}
                <span className="text-lg ml-1">km/h</span>
              </div>
            </div>
            <div className="h-12 w-px bg-border" />
            <div className="text-center">
              <div className="text-xs text-muted-foreground mb-1">Límite</div>
              <div className="text-4xl font-mono font-bold text-muted-foreground">
                {speedLimit}
                <span className="text-lg ml-1">km/h</span>
              </div>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Tiempo estimado: {estimatedTime}</span>
            <span className="text-muted-foreground">Distancia: {distance}</span>
          </div>
        </Card>
      </div>
    </div>
  );
}

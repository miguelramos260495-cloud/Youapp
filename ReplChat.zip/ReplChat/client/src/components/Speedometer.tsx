import { motion } from "framer-motion";

interface SpeedometerProps {
  speed: number; // km/h
  speedLimit?: number; // Límite de velocidad de la vía
  maxSpeed?: number; // Velocidad máxima del vehículo
  className?: string;
}

export function Speedometer({ 
  speed, 
  speedLimit = 110, 
  maxSpeed = 140,
  className = "" 
}: SpeedometerProps) {
  // Calcular el ángulo basado en la velocidad (0-180 grados)
  const maxDisplaySpeed = 160; // Velocidad máxima en el velocímetro
  const angle = Math.min((speed / maxDisplaySpeed) * 180, 180);
  
  // Determinar color basado en la velocidad
  const getSpeedColor = () => {
    if (speed === 0) return "hsl(var(--muted-foreground))";
    if (speed > speedLimit + 15) return "hsl(0 85% 55%)"; // Rojo - exceso grave
    if (speed > speedLimit) return "hsl(25 90% 55%)"; // Naranja - exceso menor
    if (speed > speedLimit - 10) return "hsl(45 95% 60%)"; // Amarillo - cerca del límite
    return "hsl(145 70% 50%)"; // Verde - velocidad segura
  };

  const speedColor = getSpeedColor();
  
  // Texto de estado
  const getStatusText = () => {
    if (speed === 0) return "Detenido";
    if (speed > speedLimit + 15) return "¡Velocidad Peligrosa!";
    if (speed > speedLimit) return "Exceso de Velocidad";
    if (speed > speedLimit - 10) return "Precaución";
    return "Velocidad Normal";
  };

  return (
    <div className={`relative ${className}`} data-testid="speedometer">
      {/* Círculo exterior */}
      <div className="relative w-32 h-32">
        {/* Fondo del velocímetro */}
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          {/* Arco de fondo */}
          <path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke="hsl(var(--border))"
            strokeWidth="8"
            strokeLinecap="round"
          />
          
          {/* Arco de velocidad */}
          <motion.path
            d="M 10 50 A 40 40 0 0 1 90 50"
            fill="none"
            stroke={speedColor}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray="125.6"
            initial={{ strokeDashoffset: 125.6 }}
            animate={{ 
              strokeDashoffset: 125.6 - (125.6 * (angle / 180))
            }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        </svg>

        {/* Aguja del velocímetro */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            className="absolute w-1 h-12 origin-bottom"
            style={{
              bottom: '50%',
              left: '50%',
              marginLeft: '-2px',
            }}
            animate={{ rotate: angle - 90 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            <div 
              className="w-full h-full rounded-full"
              style={{ backgroundColor: speedColor }}
            />
          </motion.div>
          
          {/* Centro de la aguja */}
          <div 
            className="absolute w-3 h-3 rounded-full"
            style={{ backgroundColor: speedColor }}
          />
        </div>

        {/* Velocidad digital en el centro */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pt-8">
          <motion.div
            key={speed}
            initial={{ scale: 1.2, opacity: 0.5 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.2 }}
            className="text-3xl font-bold"
            style={{ color: speedColor }}
            data-testid="speed-value"
          >
            {Math.round(speed)}
          </motion.div>
          <div className="text-xs text-muted-foreground mt-0.5">km/h</div>
        </div>
      </div>

      {/* Marcadores de velocidad */}
      <div className="flex justify-between text-xs text-muted-foreground mt-1 px-2">
        <span>0</span>
        <span>{speedLimit}</span>
        <span>{maxDisplaySpeed}</span>
      </div>

      {/* Estado de velocidad */}
      <div 
        className="text-center text-xs font-medium mt-2 transition-colors"
        style={{ color: speedColor }}
        data-testid="speed-status"
      >
        {getStatusText()}
      </div>

      {/* Límite de velocidad */}
      {speedLimit && (
        <div className="text-center text-xs text-muted-foreground mt-1">
          Límite: {speedLimit} km/h
        </div>
      )}
    </div>
  );
}

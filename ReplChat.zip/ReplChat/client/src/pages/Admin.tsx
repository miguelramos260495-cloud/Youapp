import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Plus, Trash2, Power, ShieldAlert } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { Whitelist } from "@shared/schema";

const whitelistFormSchema = z.object({
  phone: z.string().min(1, "El número de teléfono es requerido"),
  name: z.string().optional(),
  userType: z.enum(["driver", "company"]).default("driver"),
  notes: z.string().optional(),
});

type WhitelistFormData = z.infer<typeof whitelistFormSchema>;

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm<WhitelistFormData>({
    resolver: zodResolver(whitelistFormSchema),
    defaultValues: {
      phone: "",
      name: "",
      userType: "driver",
      notes: "",
    },
  });

  // Guard: Only admin can access
  if (user?.email !== "miguelramos260495@gmail.com") {
    return (
      <div className="flex items-center justify-center h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center gap-4 p-8">
            <ShieldAlert className="w-16 h-16 text-destructive" />
            <h2 className="text-2xl font-bold">Acceso Denegado</h2>
            <p className="text-muted-foreground text-center">
              No tienes permisos para acceder a esta página
            </p>
            <Button onClick={() => window.location.href = "/"}>
              Volver al Inicio
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: whitelist = [], isLoading } = useQuery<Whitelist[]>({
    queryKey: ["/api/whitelist"],
  });

  const addMutation = useMutation({
    mutationFn: async (data: WhitelistFormData) => {
      return await apiRequest("POST", "/api/whitelist", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/whitelist"] });
      toast({
        title: "✅ Agregado",
        description: "Usuario agregado a la lista blanca",
      });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo agregar a la lista",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/whitelist/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/whitelist"] });
      toast({
        title: "Eliminado",
        description: "Usuario eliminado de la lista blanca",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      return await apiRequest("POST", `/api/whitelist/${id}/toggle`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/whitelist"] });
      toast({
        title: "Actualizado",
        description: "Estado actualizado",
      });
    },
  });

  const onSubmit = (data: WhitelistFormData) => {
    addMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-muted-foreground">Cargando lista blanca...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="flex items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Panel de Administración</h1>
          <p className="text-muted-foreground mt-1">
            Control de acceso para pruebas piloto
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-whitelist">
              <Plus className="mr-2 h-4 w-4" />
              Agregar Usuario
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Agregar a Lista Blanca</DialogTitle>
              <DialogDescription>
                Agrega un número de teléfono para permitir acceso a la app
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Número de Teléfono *</FormLabel>
                      <FormControl>
                        <Input
                          data-testid="input-phone"
                          placeholder="+52 123 456 7890"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre (opcional)</FormLabel>
                      <FormControl>
                        <Input
                          data-testid="input-name"
                          placeholder="Nombre del usuario"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="userType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Usuario</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-user-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="driver">Conductor</SelectItem>
                          <SelectItem value="company">Empresa</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notas (opcional)</FormLabel>
                      <FormControl>
                        <Input
                          data-testid="input-notes"
                          placeholder="Notas sobre este usuario"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full"
                  disabled={addMutation.isPending}
                  data-testid="button-submit-whitelist"
                >
                  {addMutation.isPending ? "Agregando..." : "Agregar"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Usuarios Autorizados ({whitelist.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {whitelist.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No hay usuarios en la lista blanca
            </p>
          ) : (
            <div className="space-y-3">
              {whitelist.map((entry) => (
                <Card key={entry.id} data-testid={`card-whitelist-${entry.id}`}>
                  <CardContent className="flex items-center justify-between gap-4 p-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold" data-testid={`text-phone-${entry.id}`}>
                          {entry.phone}
                        </p>
                        {entry.name && (
                          <span className="text-sm text-muted-foreground">
                            ({entry.name})
                          </span>
                        )}
                        <Badge variant={entry.isActive ? "default" : "secondary"}>
                          {entry.isActive ? "Activo" : "Inactivo"}
                        </Badge>
                        {entry.userType && (
                          <Badge variant="outline">
                            {entry.userType === "driver" ? "Conductor" : "Empresa"}
                          </Badge>
                        )}
                      </div>
                      {entry.notes && (
                        <p className="text-sm text-muted-foreground">
                          {entry.notes}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        Agregado por: {entry.addedBy}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() =>
                          toggleMutation.mutate({
                            id: entry.id,
                            isActive: !entry.isActive,
                          })
                        }
                        disabled={toggleMutation.isPending}
                        data-testid={`button-toggle-${entry.id}`}
                      >
                        <Power className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => deleteMutation.mutate(entry.id)}
                        disabled={deleteMutation.isPending}
                        data-testid={`button-delete-${entry.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

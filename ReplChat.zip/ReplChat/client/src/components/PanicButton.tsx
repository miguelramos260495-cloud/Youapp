import { useState } from "react";
import { AlertTriangle, Shield, Scale, Heart, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { LegalAssistanceModal } from "./LegalAssistanceModal";
import { MedicalEmergencyModal } from "./MedicalEmergencyModal";
import { SafeTravelModal } from "./SafeTravelModal";

type AlertType = "robbery" | "legal" | "medical" | "safe_travel";

interface PanicButtonProps {
  onAlert: (type: AlertType, location: { lat: number; lng: number }, evidenceBlobs?: Blob[]) => void;
  className?: string;
}

const alertOptions = [
  { type: "robbery" as const, label: "Robo/Asalto", variant: "destructive" as const, icon: Shield },
  { type: "legal" as const, label: "Asistencia Legal", variant: "default" as const, icon: Scale },
  { type: "medical" as const, label: "Emergencia Médica", variant: "default" as const, icon: Heart },
  { type: "safe_travel" as const, label: "Viaje Seguro", variant: "default" as const, icon: CheckCircle },
];

export function PanicButton({ onAlert, className }: PanicButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLegalAssistanceOpen, setIsLegalAssistanceOpen] = useState(false);
  const [isMedicalEmergencyOpen, setIsMedicalEmergencyOpen] = useState(false);
  const [isSafeTravelOpen, setIsSafeTravelOpen] = useState(false);
  const [isActivating, setIsActivating] = useState(false);

  const handleAlertClick = async (type: AlertType) => {
    // For legal assistance, open the legal assistance modal instead
    if (type === "legal") {
      setIsOpen(false);
      setIsLegalAssistanceOpen(true);
      return;
    }

    // For medical emergency, open the medical emergency modal instead
    if (type === "medical") {
      setIsOpen(false);
      setIsMedicalEmergencyOpen(true);
      return;
    }

    // For safe travel, open the safe travel modal instead
    if (type === "safe_travel") {
      setIsOpen(false);
      setIsSafeTravelOpen(true);
      return;
    }

    setIsActivating(true);
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        
        onAlert(type, location);
        setIsActivating(false);
        setIsOpen(false);
      },
      (error) => {
        console.error("Error getting location:", error);
        // Continue with default location if geolocation fails
        const location = {
          lat: 25.6866,
          lng: -100.3161,
        };
        onAlert(type, location);
        setIsActivating(false);
        setIsOpen(false);
      },
      { enableHighAccuracy: false, timeout: 5000 }
    );
  };

  const handleRequestLawyer = (reason: string) => {
    // Send legal alert with specified reason
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        onAlert("legal", location);
      },
      () => {
        const location = {
          lat: 25.6866,
          lng: -100.3161,
        };
        onAlert("legal", location);
      }
    );
  };

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="destructive"
        size="lg"
        className={`fixed bottom-24 right-6 rounded-full shadow-2xl z-50 aspect-square ${className}`}
        data-testid="button-panic"
      >
        <AlertTriangle className="h-8 w-8 animate-pulse" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md" data-testid="dialog-panic-alerts">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">Selecciona el Tipo de Alerta</DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-1 gap-3 py-4">
            {alertOptions.map((option) => {
              const Icon = option.icon;
              return (
                <Button
                  key={option.type}
                  onClick={() => handleAlertClick(option.type)}
                  disabled={isActivating}
                  variant={option.variant}
                  size="lg"
                  className="justify-start gap-3"
                  data-testid={`button-alert-${option.type}`}
                >
                  <Icon className="h-6 w-6" />
                  <span>{option.label}</span>
                </Button>
              );
            })}
          </div>
          
          <p className="text-sm text-muted-foreground text-center">
            Tus contactos de emergencia serán notificados inmediatamente
          </p>
        </DialogContent>
      </Dialog>

      <LegalAssistanceModal 
        isOpen={isLegalAssistanceOpen}
        onOpenChange={setIsLegalAssistanceOpen}
        onRequestLawyer={handleRequestLawyer}
      />

      <MedicalEmergencyModal
        isOpen={isMedicalEmergencyOpen}
        onOpenChange={setIsMedicalEmergencyOpen}
        onRequestHelp={() => {
          // Send medical alert
          const location = {
            lat: 25.6866,
            lng: -100.3161,
          };
          onAlert("medical", location);
        }}
        onSaveInsurance={() => {
          // Insurance info would be saved to user profile
        }}
      />

      <SafeTravelModal
        isOpen={isSafeTravelOpen}
        onOpenChange={setIsSafeTravelOpen}
        onConfirmTravel={() => {
          // Send safe travel alert
          const location = {
            lat: 25.6866,
            lng: -100.3161,
          };
          onAlert("safe_travel", location);
        }}
        userLocation={{ lat: 25.6866, lng: -100.3161 }}
      />
    </>
  );
}

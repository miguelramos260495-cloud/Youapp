import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Calendar, Wrench, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { format, isPast, differenceInDays } from "date-fns";
import { es } from "date-fns/locale";
import type { MaintenanceReminder, Vehicle } from "@shared/schema";

const reminderTypes = [
  { value: 'service', label: 'Servicio general' },
  { value: 'oil_change', label: 'Cambio de aceite' },
  { value: 'tire_rotation', label: 'Rotación de llantas' },
  { value: 'inspection', label: 'Inspección general' },
  { value: 'emissions_verification', label: 'Verificación de emisiones contaminantes' },
  { value: 'physical_mechanical_verification', label: 'Verificación físico-mecánica' },
  { value: 'license', label: 'Renovación de licencia' },
  { value: 'insurance', label: 'Renovación de seguro' },
  { value: 'circulation_permit', label: 'Permiso de circulación' },
  { value: 'other', label: 'Otro' },
];

interface MaintenanceRemindersProps {
  vehicleId?: string;
}

export default function MaintenanceReminders({ vehicleId }: MaintenanceRemindersProps) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(vehicleId || "");
  const [type, setType] = useState("");
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [notes, setNotes] = useState("");

  const { data: reminders = [], isLoading } = useQuery<MaintenanceReminder[]>({
    queryKey: ['/api/maintenance-reminders'],
  });

  const { data: vehicles = [] } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  const createReminderMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/maintenance-reminders', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/maintenance-reminders'] });
      toast({
        title: "Recordatorio creado",
        description: "El recordatorio se ha guardado correctamente",
      });
      setShowForm(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear el recordatorio",
        variant: "destructive",
      });
    },
  });

  const completeReminderMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest('PATCH', `/api/maintenance-reminders/${id}`, { status: 'completed' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/maintenance-reminders'] });
      toast({
        title: "Recordatorio completado",
        description: "El mantenimiento se ha marcado como completado",
      });
    },
  });

  const resetForm = () => {
    setSelectedVehicle(vehicleId || "");
    setType("");
    setTitle("");
    setDueDate("");
    setNotes("");
  };

  const handleSubmit = () => {
    if (!selectedVehicle || !type || !title || !dueDate) {
      toast({
        title: "Campos requeridos",
        description: "Completa todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    createReminderMutation.mutate({
      vehicleId: selectedVehicle,
      type,
      title,
      dueDate: new Date(dueDate).toISOString(),
      notes: notes || null,
    });
  };

  const getStatusInfo = (reminder: MaintenanceReminder) => {
    if (reminder.status === 'completed') {
      return {
        icon: CheckCircle,
        color: 'text-green-600',
        bgColor: 'bg-green-50 dark:bg-green-950',
        label: 'Completado',
      };
    }

    const daysUntilDue = differenceInDays(new Date(reminder.dueDate), new Date());
    
    if (isPast(new Date(reminder.dueDate))) {
      return {
        icon: AlertCircle,
        color: 'text-red-600',
        bgColor: 'bg-red-50 dark:bg-red-950',
        label: `Vencido hace ${Math.abs(daysUntilDue)} días`,
      };
    }

    if (daysUntilDue <= 7) {
      return {
        icon: AlertCircle,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50 dark:bg-orange-950',
        label: `Vence en ${daysUntilDue} días`,
      };
    }

    return {
      icon: Clock,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50 dark:bg-blue-950',
      label: `Vence en ${daysUntilDue} días`,
    };
  };

  const filteredReminders = vehicleId
    ? reminders.filter((r) => r.vehicleId === vehicleId)
    : reminders;

  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="text-center text-muted-foreground">Cargando...</div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Wrench className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold">Recordatorios de Mantenimiento</h3>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            data-testid="button-add-reminder"
          >
            {showForm ? "Cancelar" : "Agregar Recordatorio"}
          </Button>
        </div>

        {showForm && (
          <div className="space-y-4 mb-6 p-4 border rounded-lg">
            {!vehicleId && (
              <div>
                <Label htmlFor="vehicle">Vehículo *</Label>
                <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                  <SelectTrigger id="vehicle" data-testid="select-vehicle">
                    <SelectValue placeholder="Selecciona un vehículo" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map((v: any) => (
                      <SelectItem key={v.id} value={v.id}>
                        {v.type} - {v.plate}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div>
              <Label htmlFor="type">Tipo de mantenimiento *</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger id="type" data-testid="select-type">
                  <SelectValue placeholder="Selecciona el tipo" />
                </SelectTrigger>
                <SelectContent>
                  {reminderTypes.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ej: Servicio de 10,000 km"
                data-testid="input-title"
              />
            </div>

            <div>
              <Label htmlFor="dueDate">Fecha de vencimiento *</Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                data-testid="input-due-date"
              />
            </div>

            <div>
              <Label htmlFor="notes">Notas</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Detalles adicionales..."
                data-testid="textarea-notes"
              />
            </div>

            <Button
              onClick={handleSubmit}
              disabled={createReminderMutation.isPending}
              className="w-full"
              data-testid="button-submit-reminder"
            >
              {createReminderMutation.isPending ? "Guardando..." : "Guardar Recordatorio"}
            </Button>
          </div>
        )}

        <div className="space-y-3">
          {filteredReminders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No hay recordatorios de mantenimiento
            </div>
          ) : (
            filteredReminders.map((reminder) => {
              const status = getStatusInfo(reminder);
              const StatusIcon = status.icon;
              const vehicle = vehicles.find((v: any) => v.id === reminder.vehicleId);

              return (
                <Card
                  key={reminder.id}
                  className={`p-4 ${status.bgColor}`}
                  data-testid={`reminder-${reminder.id}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <StatusIcon className={`w-5 h-5 ${status.color}`} />
                        <h4 className="font-semibold">{reminder.title}</h4>
                      </div>
                      <div className="space-y-1 text-sm">
                        {vehicle && (
                          <p className="text-muted-foreground">
                            {vehicle.type} - {vehicle.plate}
                          </p>
                        )}
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span>
                            Vence: {format(new Date(reminder.dueDate), "dd 'de' MMMM, yyyy", { locale: es })}
                          </span>
                        </div>
                        <p className={`font-medium ${status.color}`}>{status.label}</p>
                        {reminder.notes && (
                          <p className="text-muted-foreground mt-2">{reminder.notes}</p>
                        )}
                      </div>
                    </div>
                    {reminder.status === 'pending' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => completeReminderMutation.mutate(reminder.id)}
                        data-testid={`button-complete-${reminder.id}`}
                      >
                        Marcar completado
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })
          )}
        </div>
      </Card>
    </div>
  );
}

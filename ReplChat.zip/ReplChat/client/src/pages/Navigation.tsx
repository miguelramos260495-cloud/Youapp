import { useState, useRef, useMemo } from "react";
import { MapView } from "@/components/MapView";
import { InactivityDetector } from "@/components/InactivityDetector";
import { VoiceAssistant } from "@/components/VoiceAssistant";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation as NavigationIcon, X } from "lucide-react";
import type { Report, Place } from "@shared/schema";

type AlertType = "robbery" | "legal" | "medical" | "safe_travel";

export default function Navigation() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [inactivityDetectionEnabled, setInactivityDetectionEnabled] = useState(true);
  const [destination, setDestination] = useState<{ lat: number; lng: number; name: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filteredPlaces, setFilteredPlaces] = useState<Place[]>([]);
  const [showDestinationSearch, setShowDestinationSearch] = useState(false);
  const mapControlsRef = useRef<any>(null);

  const { data: reports = [] } = useQuery<Report[]>({
    queryKey: ['/api/reports'],
  });

  const { data: places = [] } = useQuery<Place[]>({
    queryKey: ['/api/places'],
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim() === "") {
      setFilteredPlaces([]);
      return;
    }
    const filtered = places.filter(place => 
      place.name.toLowerCase().includes(query.toLowerCase()) ||
      (place.address && place.address.toLowerCase().includes(query.toLowerCase()))
    );
    setFilteredPlaces(filtered);
  };

  const handleSelectDestination = (place: Place) => {
    setDestination({
      lat: place.latitude,
      lng: place.longitude,
      name: place.name
    });
    setSearchQuery(place.name);
    setShowDestinationSearch(false);
    toast({
      title: "Destino establecido",
      description: `Navegando hacia ${place.name}`,
    });
  };

  const handleClearDestination = () => {
    setDestination(null);
    setSearchQuery("");
    setFilteredPlaces([]);
    setShowDestinationSearch(false);
  };

  const mapMarkers = useMemo(() => {
    const markers: Array<{ lat: number; lng: number; type: string; label?: string }> = [];
    
    // Add report markers
    reports.forEach(report => {
      if (report.status === 'active') {
        markers.push({
          lat: report.latitude,
          lng: report.longitude,
          type: 'report',
          label: `${report.type} - ${report.description || 'Sin descripción'}`,
        });
      }
    });

    // Add place markers
    places.forEach(place => {
      markers.push({
        lat: place.latitude,
        lng: place.longitude,
        type: place.type,
        label: place.name,
      });
    });

    return markers;
  }, [reports, places]);

  const createAlertMutation = useMutation({
    mutationFn: async (data: {
      type: AlertType;
      latitude: number;
      longitude: number;
      location: string;
    }) => {
      return await apiRequest("POST", "/api/alerts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
  });

  const handleInactivityDetected = () => {
    // Automatically trigger a medical emergency alert
    navigator.geolocation.getCurrentPosition(
      (position) => {
        createAlertMutation.mutate({
          type: 'medical',
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          location: `${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)}`,
        });

        toast({
          title: "Alerta Automática Activada",
          description: "Se ha detectado inactividad prolongada. Contactos notificados.",
          variant: "destructive",
        });
      },
      () => {
        createAlertMutation.mutate({
          type: 'medical',
          latitude: 0,
          longitude: 0,
          location: "Ubicación no disponible",
        });

        toast({
          title: "Alerta Automática Activada",
          description: "Se ha detectado inactividad prolongada. Contactos notificados.",
          variant: "destructive",
        });
      }
    );
  };

  const handleVoiceCommand = (command: string, params?: any) => {
    switch (command) {
      case 'panic':
        toast({
          title: 'Comando de voz',
          description: 'Usa el botón de pánico para activar alertas',
        });
        break;
      case 'center_map':
      case 'zoom_in':
      case 'zoom_out':
        // These would trigger map controls if we had refs to the map
        toast({
          title: 'Comando de mapa',
          description: `Ejecutando: ${command}`,
        });
        break;
      case 'find_place':
        toast({
          title: 'Buscando lugares',
          description: `Buscando ${params?.type || 'lugares'} cercanos...`,
        });
        break;
      default:
        break;
    }
  };

  return (
    <div className="relative">
      <MapView 
        className="w-full" 
        markers={mapMarkers}
        destination={destination}
      />
      
      {/* Destination Search Overlay */}
      <div className="absolute top-4 left-4 right-4 z-10 max-w-md">
        {!showDestinationSearch && !destination ? (
          <Button
            onClick={() => setShowDestinationSearch(true)}
            className="w-full"
            data-testid="button-open-destination"
          >
            <MapPin className="w-4 h-4 mr-2" />
            Establecer Destino
          </Button>
        ) : destination ? (
          <Card className="p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 flex-1">
                <NavigationIcon className="w-5 h-5 text-primary" />
                <div>
                  <div className="text-sm text-muted-foreground">Navegando hacia:</div>
                  <div className="font-semibold">{destination?.name}</div>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleClearDestination}
                data-testid="button-clear-destination"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        ) : (
          <Card className="p-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Buscar destino..."
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  data-testid="input-destination-search"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowDestinationSearch(false)}
                  data-testid="button-close-destination"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              {filteredPlaces.length > 0 && (
                <div className="space-y-1 max-h-60 overflow-y-auto">
                  {filteredPlaces.slice(0, 5).map((place) => (
                    <button
                      key={place.id}
                      onClick={() => handleSelectDestination(place)}
                      className="w-full text-left p-3 rounded-md hover-elevate active-elevate-2 transition-colors"
                      data-testid={`button-select-place-${place.id}`}
                    >
                      <div className="font-medium">{place.name}</div>
                      {place.address && (
                        <div className="text-sm text-muted-foreground">{place.address}</div>
                      )}
                    </button>
                  ))}
                </div>
              )}
              
              {searchQuery && filteredPlaces.length === 0 && (
                <div className="text-center py-4 text-muted-foreground">
                  No se encontraron lugares
                </div>
              )}
            </div>
          </Card>
        )}
      </div>
      
      <VoiceAssistant onCommand={handleVoiceCommand} />
      <InactivityDetector 
        onInactivityDetected={handleInactivityDetected}
        enabled={inactivityDetectionEnabled}
        inactivityThreshold={300000} // 5 minutes
        movementThreshold={10} // 10 meters
      />
    </div>
  );
}

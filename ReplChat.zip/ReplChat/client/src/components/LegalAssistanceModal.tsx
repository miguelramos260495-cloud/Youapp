import { useState } from "react";
import { Scale, AlertTriangle, Phone, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type LegalAssistanceStep = "main" | "infraction-guide" | "illegal-detention" | "dispute-ticket";

interface LegalAssistanceModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onRequestLawyer: (reason: string) => void;
}

export function LegalAssistanceModal({ isOpen, onOpenChange, onRequestLawyer }: LegalAssistanceModalProps) {
  const [currentStep, setCurrentStep] = useState<LegalAssistanceStep>("main");

  const handleBack = () => {
    setCurrentStep("main");
  };

  const handleRequestLawyer = (reason: string) => {
    onRequestLawyer(reason);
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-legal-assistance">
        {currentStep === "main" && (
          <>
            <DialogHeader>
              <div className="flex items-center gap-2">
                <Scale className="h-6 w-6 text-blue-600" />
                <DialogTitle>Asistencia Legal</DialogTitle>
              </div>
              <DialogDescription>
                Orientación legal y conexión con profesionales
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 gap-3 py-4">
              <Card 
                className="cursor-pointer hover-elevate"
                onClick={() => setCurrentStep("infraction-guide")}
                data-testid="button-infraction-guide"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-orange-500" />
                    Guía de Infracción
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Pasos a seguir cuando te detiene un oficial de tránsito
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover-elevate"
                onClick={() => setCurrentStep("illegal-detention")}
                data-testid="button-illegal-detention"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Phone className="h-5 w-5 text-red-600" />
                    Detención Ilegal
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Crees que fuiste detenido ilegalmente. Contacta un abogado ahora
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover-elevate"
                onClick={() => setCurrentStep("dispute-ticket")}
                data-testid="button-dispute-ticket"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="h-5 w-5 text-purple-600" />
                    Impugnar Boleta
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Recursos y pasos para impugnar una infracción
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover-elevate"
                onClick={() => handleRequestLawyer("directorio-abogados")}
                data-testid="button-lawyer-directory"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Scale className="h-5 w-5 text-blue-600" />
                    Directorio de Abogados
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Busca asesores jurídicos especializados en transporte
                  </p>
                </CardContent>
              </Card>
            </div>
          </>
        )}

        {currentStep === "infraction-guide" && (
          <>
            <DialogHeader>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-4"
                onClick={handleBack}
                data-testid="button-back"
              >
                <X className="h-4 w-4" />
              </Button>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                Guía de Infracción
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                <h3 className="font-semibold text-amber-900 dark:text-amber-100 mb-3">
                  Pasos a Seguir ante un Oficial de Tránsito
                </h3>
                <ol className="space-y-2 text-sm text-amber-800 dark:text-amber-100">
                  <li><strong>1. Mantén la Calma:</strong> Respira profundo y sé cortés</li>
                  <li><strong>2. Detén el Vehículo:</strong> En un lugar seguro y con visibilidad</li>
                  <li><strong>3. Documentos Listos:</strong> Licencia, registro y seguro a mano</li>
                  <li><strong>4. Escucha:</strong> Permite que el oficial hable primero</li>
                  <li><strong>5. Sé Respetuoso:</strong> Nunca confrontes o desafíes al oficial</li>
                  <li><strong>6. No Admitas Culpa:</strong> Escucha la infracción pero no reconozcas culpabilidad</li>
                  <li><strong>7. Solicita Documentación:</strong> Pide que vea la razón de la parada</li>
                  <li><strong>8. Anota Todo:</strong> Hora, lugar, oficial, placa y cámara corporal</li>
                  <li><strong>9. Recurso Legal:</strong> Pregunta sobre tu derecho a impugnar</li>
                </ol>
              </div>

              <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                  Tus Derechos
                </h3>
                <ul className="text-sm text-blue-800 dark:text-blue-100 space-y-1">
                  <li>✓ Derecho a permanecer en silencio</li>
                  <li>✓ Derecho a solicitar abogado</li>
                  <li>✓ Derecho a conocer la infracción</li>
                  <li>✓ Derecho a impugnar en tribunal</li>
                </ul>
              </div>

              <Button
                onClick={() => handleRequestLawyer("infraction-guide")}
                className="w-full"
                data-testid="button-request-lawyer-infraction"
              >
                Contactar un Abogado
              </Button>
            </div>
          </>
        )}

        {currentStep === "illegal-detention" && (
          <>
            <DialogHeader>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-4"
                onClick={handleBack}
                data-testid="button-back"
              >
                <X className="h-4 w-4" />
              </Button>
              <DialogTitle className="flex items-center gap-2 text-red-600">
                <Phone className="h-5 w-5" />
                Detención Ilegal
              </DialogTitle>
              <DialogDescription>
                Si crees que fuiste detenido sin justificación legal
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-4">
                <h3 className="font-semibold text-red-900 dark:text-red-100 mb-2">
                  Indicios de Detención Ilegal
                </h3>
                <ul className="text-sm text-red-800 dark:text-red-100 space-y-1">
                  <li>• Sin causa probable o sospecha razonable</li>
                  <li>• Sin identificación clara del oficial</li>
                  <li>• Más tiempo del permitido sin explicación</li>
                  <li>• Revisión de vehículo sin consentimiento</li>
                  <li>• Lenguaje discriminatorio o acoso</li>
                </ul>
              </div>

              <div className="bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-900 dark:text-yellow-100 mb-2">
                  Acción Inmediata
                </h3>
                <p className="text-sm text-yellow-800 dark:text-yellow-100">
                  1. Solicita claramente: "Soy libre de irme"<br/>
                  2. Si dice que no: "Quiero un abogado"<br/>
                  3. No resistas físicamente<br/>
                  4. Documenta todo: nombres, hora, lugar<br/>
                  5. Contacta un abogado inmediatamente
                </p>
              </div>

              <Button
                onClick={() => handleRequestLawyer("illegal-detention")}
                variant="destructive"
                className="w-full"
                data-testid="button-request-lawyer-illegal"
              >
                Contactar Abogado - URGENTE
              </Button>
            </div>
          </>
        )}

        {currentStep === "dispute-ticket" && (
          <>
            <DialogHeader>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-4"
                onClick={handleBack}
                data-testid="button-back"
              >
                <X className="h-4 w-4" />
              </Button>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-purple-600" />
                Impugnar Boleta
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
                <h3 className="font-semibold text-purple-900 dark:text-purple-100 mb-3">
                  Proceso de Impugnación
                </h3>
                <ol className="space-y-2 text-sm text-purple-800 dark:text-purple-100">
                  <li><strong>1. Obtén Copia:</strong> Solicita copia de la boleta al oficial</li>
                  <li><strong>2. Revisa Datos:</strong> Verifica que todos los datos sean correctos</li>
                  <li><strong>3. Investigación:</strong> Recaba pruebas (fotos, testimonios, cámaras)</li>
                  <li><strong>4. Límite de Tiempo:</strong> Generalmente 15-30 días para impugnar</li>
                  <li><strong>5. Procedimiento Legal:</strong> Presenta ante juzgado de tránsito</li>
                  <li><strong>6. Audiencia:</strong> Comparece ante el juez con pruebas</li>
                </ol>
              </div>

              <div className="bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-lg p-4">
                <h3 className="font-semibold text-green-900 dark:text-green-100 mb-2">
                  Razones Válidas para Impugnar
                </h3>
                <ul className="text-sm text-green-800 dark:text-green-100 space-y-1">
                  <li>✓ Datos incorrectos en la boleta</li>
                  <li>✓ Falta de causa legal</li>
                  <li>✓ Error del oficial (velocidad, ubicación)</li>
                  <li>✓ Cámara del vehículo muestra inocencia</li>
                  <li>✓ Procedimiento incorrecto</li>
                </ul>
              </div>

              <Button
                onClick={() => handleRequestLawyer("dispute-ticket")}
                className="w-full"
                data-testid="button-request-lawyer-dispute"
              >
                Consultar Abogado para Impugnación
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

import { Construction, AlertCircle, Car, ShieldAlert, MapPinOff, BadgeAlert } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { Report } from "@shared/schema";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface ReportCardProps {
  report: Report;
  onClick?: () => void;
}

const reportConfig = {
  checkpoint: {
    icon: ShieldAlert,
    label: "Retén",
    color: "border-warning",
    bgColor: "bg-warning/10",
    textColor: "text-warning",
  },
  accident: {
    icon: Car,
    label: "Accidente",
    color: "border-emergency",
    bgColor: "bg-emergency/10",
    textColor: "text-emergency",
  },
  construction: {
    icon: Construction,
    label: "Obra",
    color: "border-caution",
    bgColor: "bg-caution/10",
    textColor: "text-caution",
  },
  closure: {
    icon: MapPinOff,
    label: "Cierre",
    color: "border-destructive",
    bgColor: "bg-destructive/10",
    textColor: "text-destructive",
  },
  hazard: {
    icon: AlertCircle,
    label: "Peligro",
    color: "border-emergency",
    bgColor: "bg-emergency/10",
    textColor: "text-emergency",
  },
  police: {
    icon: BadgeAlert,
    label: "Policía",
    color: "border-primary",
    bgColor: "bg-primary/10",
    textColor: "text-primary",
  },
};

const severityConfig = {
  low: { label: "Baja", variant: "secondary" as const },
  medium: { label: "Media", variant: "default" as const },
  high: { label: "Alta", variant: "destructive" as const },
};

const statusConfig = {
  active: { label: "Activo", variant: "default" as const },
  expired: { label: "Expirado", variant: "secondary" as const },
  resolved: { label: "Resuelto", variant: "outline" as const },
};

export function ReportCard({ report, onClick }: ReportCardProps) {
  const config = reportConfig[report.type as keyof typeof reportConfig];
  const Icon = config.icon;
  const severity = severityConfig[report.severity as keyof typeof severityConfig];
  const status = statusConfig[report.status as keyof typeof statusConfig];
  const confirmations = report.confirmedBy?.length || 0;

  return (
    <Card
      className={cn(
        "p-4 border-l-4 hover-elevate active-elevate-2 transition-all cursor-pointer",
        config.color
      )}
      onClick={onClick}
      data-testid={`card-report-${report.id}`}
    >
      <div className="flex items-start gap-4">
        <div className={cn("p-2 rounded-lg", config.bgColor)}>
          <Icon className={cn("w-8 h-8", config.textColor)} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-lg">{config.label}</h3>
            <div className="flex gap-2">
              <Badge variant={severity.variant} className="shrink-0">
                {severity.label}
              </Badge>
              <Badge variant={status.variant} className="shrink-0">
                {status.label}
              </Badge>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mb-2">{report.location}</p>
          {report.description && (
            <p className="text-sm mb-3">{report.description}</p>
          )}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {format(new Date(report.createdAt), "dd MMM yyyy, HH:mm", { locale: es })}
            </span>
            {confirmations > 0 && (
              <span className="text-primary">
                {confirmations} {confirmations === 1 ? "confirmación" : "confirmaciones"}
              </span>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

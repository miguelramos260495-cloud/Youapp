import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ReportCard } from "@/components/ReportCard";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Plus } from "lucide-react";
import reportsImage from "@assets/generated_images/community_reports_and_alerts.png";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Reports() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<string>("");
  const [severity, setSeverity] = useState<string>("medium");
  const [description, setDescription] = useState("");

  const { data: reports, isLoading } = useQuery<any[]>({
    queryKey: ["/api/reports"],
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/reports", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({
        title: "Reporte creado",
        description: "Tu reporte ha sido enviado a la comunidad",
      });
      setOpen(false);
      setType("");
      setDescription("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo crear el reporte",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!type) {
      toast({
        title: "Tipo requerido",
        description: "Selecciona el tipo de reporte",
        variant: "destructive",
      });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        createReportMutation.mutate({
          type,
          severity,
          description,
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          location: `${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)}`,
        });
      },
      () => {
        toast({
          title: "Error de ubicación",
          description: "No se pudo obtener tu ubicación",
          variant: "destructive",
        });
      }
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando reportes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <div className="relative h-48 md:h-64 overflow-hidden rounded-b-lg">
        <img
          src={reportsImage}
          alt="Reportes comunitarios"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>
      <div className="p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-start justify-between mb-8 gap-4">
            <div className="flex items-start gap-4 flex-1">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-orange-500/10 to-orange-600/10 border border-orange-500/20">
                <Bell className="w-12 h-12 text-orange-500" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl md:text-4xl font-bold mb-2">Reportes Comunitarios</h1>
                <p className="text-muted-foreground">
                  Alertas viales compartidas por la comunidad
                </p>
              </div>
            </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-new-report" className="shrink-0">
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Reporte
              </Button>
            </DialogTrigger>
          </div>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Crear Reporte Vial</DialogTitle>
                <DialogDescription>
                  Comparte información sobre situaciones en la carretera
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Tipo de Reporte</Label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger data-testid="select-report-type">
                      <SelectValue placeholder="Selecciona un tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="checkpoint">Retén</SelectItem>
                      <SelectItem value="accident">Accidente</SelectItem>
                      <SelectItem value="construction">Obra en Construcción</SelectItem>
                      <SelectItem value="closure">Cierre de Vía</SelectItem>
                      <SelectItem value="hazard">Peligro en Carretera</SelectItem>
                      <SelectItem value="police">Presencia Policial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Gravedad</Label>
                  <Select value={severity} onValueChange={setSeverity}>
                    <SelectTrigger data-testid="select-severity">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Baja</SelectItem>
                      <SelectItem value="medium">Media</SelectItem>
                      <SelectItem value="high">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Descripción (opcional)</Label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Detalles adicionales..."
                    data-testid="input-description"
                  />
                </div>
                <Button
                  onClick={handleSubmit}
                  className="w-full"
                  disabled={createReportMutation.isPending}
                  data-testid="button-submit-report"
                >
                  {createReportMutation.isPending ? "Enviando..." : "Crear Reporte"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {!reports || reports.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 rounded-full bg-primary/10">
                <Bell className="w-12 h-12 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Sin reportes disponibles</h3>
              <p className="text-muted-foreground max-w-md">
                Sé el primero en compartir información sobre situaciones en la carretera
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            {reports.map((report) => (
              <ReportCard key={report.id} report={report} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import { useState } from "react";
import { Heart, Phone, AlertTriangle, X, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface InsuranceInfo {
  company: string;
  phone: string;
  policyNumber: string;
}

interface MedicalEmergencyModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onRequestHelp: (type: "insurance" | "ambulance" | "088" | "911") => void;
  onSaveInsurance: (insurance: InsuranceInfo) => void;
}

export function MedicalEmergencyModal({
  isOpen,
  onOpenChange,
  onRequestHelp,
  onSaveInsurance,
}: MedicalEmergencyModalProps) {
  const { toast } = useToast();
  const [showAddInsurance, setShowAddInsurance] = useState(false);
  const [insuranceInfo, setInsuranceInfo] = useState<InsuranceInfo>({
    company: "",
    phone: "",
    policyNumber: "",
  });
  const [savedInsurance, setSavedInsurance] = useState<InsuranceInfo | null>(null);

  const handleSaveInsurance = () => {
    if (!insuranceInfo.company || !insuranceInfo.phone || !insuranceInfo.policyNumber) {
      toast({
        title: "Información incompleta",
        description: "Por favor completa todos los campos del seguro",
        variant: "destructive",
      });
      return;
    }

    setSavedInsurance(insuranceInfo);
    onSaveInsurance(insuranceInfo);
    setShowAddInsurance(false);
    toast({
      title: "Seguro guardado",
      description: `${insuranceInfo.company} registrado correctamente`,
    });
  };

  const handleEmergencyCall = (type: "insurance" | "ambulance" | "088" | "911", phone: string) => {
    if (phone) {
      window.location.href = `tel:${phone}`;
    }
    onRequestHelp(type);
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-medical-emergency">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-red-600" />
            <DialogTitle>Emergencia Médica</DialogTitle>
          </div>
          <DialogDescription>
            Acceso rápido a recursos médicos de emergencia
          </DialogDescription>
        </DialogHeader>

        {!showAddInsurance ? (
          <div className="space-y-4 py-4">
            {/* Insurance Card */}
            <Card className="border-blue-200 dark:border-blue-800" data-testid="card-insurance">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Heart className="h-5 w-5 text-blue-600" />
                  Mi Seguro Médico
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {savedInsurance ? (
                  <div className="bg-blue-50 dark:bg-blue-950/30 p-4 rounded-lg space-y-2">
                    <p className="font-semibold text-blue-900 dark:text-blue-100">
                      {savedInsurance.company}
                    </p>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <a
                        href={`tel:${savedInsurance.phone}`}
                        className="text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                        data-testid="link-insurance-phone"
                      >
                        {savedInsurance.phone}
                      </a>
                    </div>
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      Póliza: {savedInsurance.policyNumber}
                    </p>
                    <Button
                      onClick={() => handleEmergencyCall("insurance", savedInsurance.phone)}
                      className="w-full mt-2"
                      data-testid="button-call-insurance"
                    >
                      Llamar a Mi Seguro
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowAddInsurance(true)}
                      className="w-full"
                      data-testid="button-change-insurance"
                    >
                      Cambiar Seguro
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={() => setShowAddInsurance(true)}
                    variant="outline"
                    className="w-full"
                    data-testid="button-add-insurance"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Registrar Mi Seguro Médico
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Emergency Services */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Ambulancia */}
              <Card className="border-orange-200 dark:border-orange-800 cursor-pointer hover-elevate"
                data-testid="card-ambulance"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Phone className="h-5 w-5 text-orange-600" />
                    Ambulancia
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">
                    Solicita una ambulancia de emergencia
                  </p>
                  <Button
                    onClick={() => handleEmergencyCall("ambulance", "066")}
                    className="w-full bg-orange-600 hover:bg-orange-700"
                    data-testid="button-call-ambulance"
                  >
                    Llamar Ambulancia
                  </Button>
                </CardContent>
              </Card>

              {/* 088 - Emergencias Médicas */}
              <Card className="border-red-200 dark:border-red-800 cursor-pointer hover-elevate"
                data-testid="card-088"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    Emergencias Médicas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">
                    Línea de emergencias médicas en carretera
                  </p>
                  <Button
                    onClick={() => handleEmergencyCall("088", "088")}
                    className="w-full bg-red-600 hover:bg-red-700"
                    data-testid="button-call-088"
                  >
                    Llamar 088
                  </Button>
                </CardContent>
              </Card>

              {/* 911 */}
              <Card className="border-red-200 dark:border-red-800 cursor-pointer hover-elevate"
                data-testid="card-911"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    Emergencia 911
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">
                    Línea de emergencias general - Ambulancia, Bomberos, Policía
                  </p>
                  <Button
                    onClick={() => handleEmergencyCall("911", "911")}
                    className="w-full bg-red-600 hover:bg-red-700"
                    data-testid="button-call-911"
                  >
                    Llamar 911
                  </Button>
                </CardContent>
              </Card>

              {/* Médico de Confianza */}
              <Card className="border-green-200 dark:border-green-800 cursor-pointer hover-elevate"
                data-testid="card-doctor"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Phone className="h-5 w-5 text-green-600" />
                    Médico Particular
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">
                    Contacta a tu médico de confianza
                  </p>
                  <Button
                    variant="outline"
                    className="w-full"
                    disabled
                    data-testid="button-doctor-placeholder"
                  >
                    Guardar en Perfil
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <h3 className="font-semibold text-red-900 dark:text-red-100 mb-2 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Importante
              </h3>
              <p className="text-sm text-red-800 dark:text-red-100">
                Al presionar cualquiera de estos botones, tus contactos de emergencia serán notificados de inmediato con tu ubicación actual.
              </p>
            </div>
          </div>
        ) : (
          /* Add Insurance Form */
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Registrar Seguro Médico</h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowAddInsurance(false)}
                data-testid="button-close-insurance-form"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium mb-1 block">
                  Nombre de la Aseguradora
                </label>
                <Input
                  placeholder="Ej: Seguros Monterrey"
                  value={insuranceInfo.company}
                  onChange={(e) =>
                    setInsuranceInfo({ ...insuranceInfo, company: e.target.value })
                  }
                  data-testid="input-insurance-company"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">
                  Número Telefónico de Emergencia
                </label>
                <Input
                  placeholder="Ej: +52 81 2345 6789"
                  value={insuranceInfo.phone}
                  onChange={(e) =>
                    setInsuranceInfo({ ...insuranceInfo, phone: e.target.value })
                  }
                  data-testid="input-insurance-phone"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">
                  Número de Póliza
                </label>
                <Input
                  placeholder="Ej: POL-123456789"
                  value={insuranceInfo.policyNumber}
                  onChange={(e) =>
                    setInsuranceInfo({ ...insuranceInfo, policyNumber: e.target.value })
                  }
                  data-testid="input-insurance-policy"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowAddInsurance(false)}
                className="flex-1"
                data-testid="button-cancel-insurance"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSaveInsurance}
                className="flex-1"
                data-testid="button-save-insurance"
              >
                Guardar Seguro
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

import { useState, useEffect } from "react";
import { CheckCircle, MapPin, Star, Shield, Building2, Home, Coffee, Utensils, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface SafePlace {
  id: string;
  name: string;
  type: "hotel" | "motel" | "pension" | "safe-zone" | "restaurant";
  address: string;
  distance: number; // km
  rating: number; // 1-5
  userReviews: number;
  safetyRating: number; // 1-5 based on user reports
  phone: string;
  amenities: string[];
}

interface SafeTravelModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirmTravel: (place: SafePlace) => void;
  userLocation?: { lat: number; lng: number };
}

const mockSafePlaces: SafePlace[] = [
  {
    id: "hotel-1",
    name: "Hotel La Seguridad",
    type: "hotel",
    address: "Blvd. Principal 123, Monterrey",
    distance: 2.3,
    rating: 4.8,
    userReviews: 156,
    safetyRating: 4.9,
    phone: "+52 81 8000 1234",
    amenities: ["Vigilancia 24/7", "Cámaras de seguridad", "Personal entrenado", "Parqueo seguro"],
  },
  {
    id: "motel-1",
    name: "Motel Protección",
    type: "motel",
    address: "Carretera Federal 45, km 123",
    distance: 5.1,
    rating: 4.5,
    userReviews: 89,
    safetyRating: 4.7,
    phone: "+52 81 8000 5678",
    amenities: ["Vigilancia", "Parqueo cerrado", "Desayuno incluido", "WiFi"],
  },
  {
    id: "pension-1",
    name: "Pensión del Camionero",
    type: "pension",
    address: "Calle Transportistas 456, Saltillo",
    distance: 8.7,
    rating: 4.6,
    userReviews: 203,
    safetyRating: 4.8,
    phone: "+52 844 1111 2222",
    amenities: ["Recomendada por camioneros", "Comida casera", "Ambiente seguro", "Estacionamiento amplio"],
  },
  {
    id: "restaurant-1",
    name: "Comedor Camionero El Buen Sabor",
    type: "restaurant",
    address: "Carretera Federal 45, Km 280",
    distance: 4.2,
    rating: 4.7,
    userReviews: 342,
    safetyRating: 4.8,
    phone: "+52 81 2000 1111",
    amenities: ["Comida casera", "Precios económicos", "Porción generosa", "Ambiente familiar", "Estacionamiento seguro"],
  },
  {
    id: "restaurant-2",
    name: "Restaurante La Ruta del Chofer",
    type: "restaurant",
    address: "Salida a Saltillo, Plaza Comercial Centro",
    distance: 6.5,
    rating: 4.6,
    userReviews: 278,
    safetyRating: 4.7,
    phone: "+52 844 2000 2222",
    amenities: ["Especialidad en carnes", "Buffet al mediodía", "Buen trato", "Ambiente limpio", "WiFi gratis"],
  },
  {
    id: "restaurant-3",
    name: "Cocina de Casa - Comidas Tradicionales",
    type: "restaurant",
    address: "Centro Comercial Vías, Querétaro",
    distance: 10.3,
    rating: 4.8,
    userReviews: 456,
    safetyRating: 4.9,
    phone: "+52 442 3000 3333",
    amenities: ["Comida mexicana auténtica", "Precios justos", "Personal atento", "Menú diario económico", "Agua fresca casera"],
  },
  {
    id: "safe-zone-1",
    name: "Área Segura de Descanso - Gasolinería PEMEX",
    type: "safe-zone",
    address: "Salida a San Juan del Río",
    distance: 3.2,
    rating: 4.7,
    userReviews: 412,
    safetyRating: 4.9,
    phone: "+52 442 2222 3333",
    amenities: ["Vigilancia policial", "Servicios básicos", "Bien iluminada", "Comunidad de conductores"],
  },
  {
    id: "hotel-2",
    name: "Hotel Express Seguro",
    type: "hotel",
    address: "Zona Comercial Sur, Querétaro",
    distance: 12.5,
    rating: 4.4,
    userReviews: 78,
    safetyRating: 4.6,
    phone: "+52 442 3333 4444",
    amenities: ["Personal profesional", "Control de acceso", "Recepción 24/7", "Cafetería"],
  },
  {
    id: "restaurant-4",
    name: "El Asadero del Transportista",
    type: "restaurant",
    address: "Carretera Federal 150, Apodaca",
    distance: 2.8,
    rating: 4.9,
    userReviews: 521,
    safetyRating: 4.9,
    phone: "+52 81 4000 4444",
    amenities: ["Carne asada premium", "Precio competitivo", "Trato excepcional", "Estacionamiento amplio", "Música en vivo fines de semana"],
  },
  {
    id: "safe-zone-2",
    name: "Módulo de Seguridad Vial - Federal 150",
    type: "safe-zone",
    address: "Carretera Federal 150 norte",
    distance: 15.3,
    rating: 4.8,
    userReviews: 567,
    safetyRating: 4.9,
    phone: "+52 55 5555 6666",
    amenities: ["Protección estatal", "Personal capacitado", "Zona de descanso", "Información de rutas seguras"],
  },
];

export function SafeTravelModal({
  isOpen,
  onOpenChange,
  onConfirmTravel,
  userLocation,
}: SafeTravelModalProps) {
  const [selectedPlace, setSelectedPlace] = useState<SafePlace | null>(null);
  const [filterType, setFilterType] = useState<"all" | "hotel" | "motel" | "pension" | "safe-zone" | "restaurant">("all");

  const filteredPlaces = mockSafePlaces.filter(
    (place) => filterType === "all" || place.type === filterType
  );

  const getTypeIcon = (type: SafePlace["type"]) => {
    switch (type) {
      case "hotel":
        return <Building2 className="h-5 w-5 text-blue-600" />;
      case "motel":
        return <Home className="h-5 w-5 text-green-600" />;
      case "pension":
        return <Coffee className="h-5 w-5 text-orange-600" />;
      case "restaurant":
        return <Utensils className="h-5 w-5 text-purple-600" />;
      case "safe-zone":
        return <Shield className="h-5 w-5 text-red-600" />;
    }
  };

  const getTypeLabel = (type: SafePlace["type"]) => {
    const labels = {
      hotel: "Hotel",
      motel: "Motel",
      pension: "Pensión",
      restaurant: "Restaurante",
      "safe-zone": "Área Segura",
    };
    return labels[type];
  };

  const getSafetyColor = (rating: number) => {
    if (rating >= 4.7) return "text-green-600";
    if (rating >= 4.3) return "text-yellow-600";
    return "text-orange-600";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-safe-travel">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-6 w-6 text-green-600" />
            <DialogTitle>Viaje Seguro</DialogTitle>
          </div>
          <DialogDescription>
            Hoteles, moteles, pensiones y áreas seguras cercanas con vigilancia recomendada
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Filter Buttons */}
          <div className="flex flex-wrap gap-2" data-testid="filter-buttons">
            <Button
              variant={filterType === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("all")}
              data-testid="filter-all"
            >
              Todos
            </Button>
            <Button
              variant={filterType === "hotel" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("hotel")}
              data-testid="filter-hotel"
            >
              Hoteles
            </Button>
            <Button
              variant={filterType === "motel" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("motel")}
              data-testid="filter-motel"
            >
              Moteles
            </Button>
            <Button
              variant={filterType === "pension" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("pension")}
              data-testid="filter-pension"
            >
              Pensiones
            </Button>
            <Button
              variant={filterType === "restaurant" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("restaurant")}
              data-testid="filter-restaurant"
            >
              Restaurantes
            </Button>
            <Button
              variant={filterType === "safe-zone" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("safe-zone")}
              data-testid="filter-safe-zone"
            >
              Áreas Seguras
            </Button>
          </div>

          {/* Places Grid */}
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredPlaces.map((place) => (
              <Card
                key={place.id}
                className="cursor-pointer hover-elevate transition-all"
                onClick={() => setSelectedPlace(place)}
                data-testid={`card-place-${place.id}`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2 flex-1">
                      {getTypeIcon(place.type)}
                      <div className="flex-1">
                        <CardTitle className="text-base">{place.name}</CardTitle>
                        <p className="text-xs text-muted-foreground mt-1">{getTypeLabel(place.type)}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="shrink-0">
                      {place.distance} km
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{place.address}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                      <span className="font-medium">{place.rating}/5</span>
                      <span className="text-muted-foreground">({place.userReviews})</span>
                    </div>

                    <div className={`flex items-center gap-1 font-medium ${getSafetyColor(place.safetyRating)}`}>
                      <Shield className="h-4 w-4" />
                      <span>Seguridad {place.safetyRating}/5</span>
                    </div>
                  </div>

                  {place.amenities.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-2">
                      {place.amenities.slice(0, 3).map((amenity, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {amenity}
                        </Badge>
                      ))}
                      {place.amenities.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{place.amenities.length - 3} más
                        </Badge>
                      )}
                    </div>
                  )}

                  <Button
                    onClick={() => window.location.href = `tel:${place.phone}`}
                    variant="outline"
                    size="sm"
                    className="w-full mt-2"
                    data-testid={`button-call-${place.id}`}
                  >
                    Llamar: {place.phone}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Info Box */}
          <div className="bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-lg p-4">
            <h3 className="font-semibold text-green-900 dark:text-green-100 mb-2 flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Recomendaciones de Seguridad
            </h3>
            <ul className="text-sm text-green-800 dark:text-green-100 space-y-1">
              <li>✓ Los lugares están clasificados por reseñas de conductores</li>
              <li>✓ Se prioriza vigilancia 24/7 y control de acceso</li>
              <li>✓ Todos tienen personal entrenado en seguridad</li>
              <li>✓ Al llegar, notifica tu ubicación a contactos de confianza</li>
            </ul>
          </div>

          {/* Confirmation Section */}
          {selectedPlace && (
            <Card className="border-primary/50 bg-primary/5">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center justify-between">
                  <span>Lugarseleccionado</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedPlace(null)}
                    data-testid="button-clear-selection"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm font-medium">{selectedPlace.name}</p>
                <Button
                  onClick={() => {
                    onConfirmTravel(selectedPlace);
                    onOpenChange(false);
                  }}
                  className="w-full"
                  data-testid="button-confirm-travel"
                >
                  Confirmar Viaje Seguro a {selectedPlace.name}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

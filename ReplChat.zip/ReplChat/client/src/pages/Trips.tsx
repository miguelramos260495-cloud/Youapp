import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Navigation, Clock } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import tripsImage from "@assets/generated_images/truck_journey_and_road_logistics.png";

export default function Trips() {
  const { data: trips, isLoading } = useQuery<any[]>({
    queryKey: ["/api/trips"],
  });

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando viajes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <div className="relative h-48 md:h-64 overflow-hidden rounded-b-lg">
        <img
          src={tripsImage}
          alt="Bitácora de viajes"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>
      <div className="p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 flex items-start gap-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20">
              <Navigation className="w-12 h-12 text-blue-500" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Bitácora de Viajes</h1>
              <p className="text-muted-foreground">
                Historial completo de tus trayectos y eventos en carretera
              </p>
            </div>
          </div>

        {!trips || trips.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 rounded-full bg-primary/10">
                <Navigation className="w-12 h-12 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Sin viajes registrados</h3>
              <p className="text-muted-foreground max-w-md">
                Tus viajes se registrarán automáticamente cuando uses la navegación
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
      {trips.map((trip) => (
              <Card
                key={trip.id}
                className="p-6 hover-elevate active-elevate-2 transition-all"
                data-testid={`card-trip-${trip.id}`}
              >
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge
                        variant={trip.status === "active" ? "default" : "secondary"}
                        data-testid="badge-trip-status"
                      >
                        {trip.status === "active" ? "En curso" : "Completado"}
                      </Badge>
                      {trip.roadType && (
                        <Badge variant="outline">
                          {trip.roadType === "federal"
                            ? "Federal"
                            : trip.roadType === "state"
                            ? "Estatal"
                            : "Municipal"}
                        </Badge>
                      )}
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <MapPin className="w-4 h-4 text-safe shrink-0 mt-1" />
                        <div>
                          <div className="text-sm font-medium">Origen</div>
                          <div className="text-sm text-muted-foreground">
                            {trip.startLocation}
                          </div>
                        </div>
                      </div>
                      {trip.endLocation && (
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-emergency shrink-0 mt-1" />
                          <div>
                            <div className="text-sm font-medium">Destino</div>
                            <div className="text-sm text-muted-foreground">
                              {trip.endLocation}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <div className="text-xs text-muted-foreground">Inicio</div>
                      <div className="text-sm font-mono">
                        {format(new Date(trip.startTime), "dd/MM HH:mm", { locale: es })}
                      </div>
                    </div>
                  </div>
                  {trip.distance && (
                    <div className="flex items-center gap-2">
                      <Navigation className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Distancia</div>
                        <div className="text-sm font-mono">{trip.distance.toFixed(1)} km</div>
                      </div>
                    </div>
                  )}
                  {trip.avgSpeed && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Vel. Promedio</div>
                        <div className="text-sm font-mono">{trip.avgSpeed.toFixed(0)} km/h</div>
                      </div>
                    </div>
                  )}
                  {trip.maxSpeed && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Vel. Máxima</div>
                        <div className="text-sm font-mono">{trip.maxSpeed.toFixed(0)} km/h</div>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Fuel, 
  Utensils, 
  Bath, 
  Search, 
  Package, 
  PackageOpen, 
  AlertTriangle, 
  Wrench,
  BedDouble,
  Clock
} from "lucide-react";

interface StopReasonModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: (reason: string, type: string, notes?: string) => void;
  currentLocation: string;
}

const STOP_REASONS = [
  { 
    type: 'refuel', 
    label: 'Combustible', 
    icon: Fuel,
    color: 'hsl(215 85% 55%)'
  },
  { 
    type: 'meal', 
    label: 'Comida', 
    icon: Utensils,
    color: 'hsl(25 90% 55%)'
  },
  { 
    type: 'restroom', 
    label: 'Baño', 
    icon: Bath,
    color: 'hsl(145 70% 50%)'
  },
  { 
    type: 'rest', 
    label: 'Descanso', 
    icon: BedDouble,
    color: 'hsl(270 70% 60%)'
  },
  { 
    type: 'inspection', 
    label: 'Revisión', 
    icon: Search,
    color: 'hsl(45 95% 60%)'
  },
  { 
    type: 'loading', 
    label: 'Carga', 
    icon: Package,
    color: 'hsl(190 80% 50%)'
  },
  { 
    type: 'unloading', 
    label: 'Descarga', 
    icon: PackageOpen,
    color: 'hsl(160 70% 50%)'
  },
  { 
    type: 'maintenance', 
    label: 'Mantenimiento', 
    icon: Wrench,
    color: 'hsl(280 60% 55%)'
  },
  { 
    type: 'emergency', 
    label: 'Emergencia', 
    icon: AlertTriangle,
    color: 'hsl(0 85% 55%)'
  },
];

export function StopReasonModal({ 
  open, 
  onClose, 
  onConfirm,
  currentLocation 
}: StopReasonModalProps) {
  const [selectedReason, setSelectedReason] = useState<string | null>(null);
  const [notes, setNotes] = useState("");

  const handleConfirm = () => {
    if (!selectedReason) return;
    
    const reason = STOP_REASONS.find(r => r.type === selectedReason);
    if (reason) {
      onConfirm(reason.label, reason.type, notes || undefined);
      setSelectedReason(null);
      setNotes("");
    }
  };

  const handleClose = () => {
    setSelectedReason(null);
    setNotes("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" data-testid="stop-reason-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Registrar Parada
          </DialogTitle>
          <DialogDescription>
            Selecciona el motivo de tu parada. Ubicación: {currentLocation}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-3 gap-3 py-4">
          {STOP_REASONS.map((reason) => {
            const Icon = reason.icon;
            const isSelected = selectedReason === reason.type;
            
            return (
              <Button
                key={reason.type}
                variant={isSelected ? "default" : "outline"}
                className="h-20 flex flex-col gap-1 hover-elevate active-elevate-2"
                onClick={() => setSelectedReason(reason.type)}
                style={isSelected ? { 
                  backgroundColor: reason.color,
                  borderColor: reason.color,
                  color: 'white'
                } : undefined}
                data-testid={`stop-reason-${reason.type}`}
              >
                <Icon className="w-6 h-6" />
                <span className="text-xs">{reason.label}</span>
              </Button>
            );
          })}
        </div>

        {selectedReason && (
          <div className="space-y-3">
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Notas adicionales (opcional)
              </label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ej: Recarga 200 litros, Tiempo estimado: 30 min..."
                className="resize-none"
                rows={3}
                data-testid="stop-notes-input"
              />
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={handleClose}
                className="flex-1"
                data-testid="button-cancel-stop"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleConfirm}
                className="flex-1"
                data-testid="button-confirm-stop"
              >
                Registrar Parada
              </Button>
            </div>
          </div>
        )}

        {!selectedReason && (
          <div className="text-center text-sm text-muted-foreground">
            Selecciona un motivo para continuar
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

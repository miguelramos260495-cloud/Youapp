import { db } from "./db";
import { infractions } from "@shared/schema";

// RTCPJF 2025 - Tabulador de Infracciones
// UMA 2025 = $108.57 MXN
const UMA_2025 = 108.57;

const infractionData = [
  // VELOCIDAD
  {
    code: "ART-24-I",
    title: "Exceso de velocidad hasta 20 km/h",
    description: "Circular a velocidad mayor a la permitida, sin exceder 20 km/h",
    category: "speed",
    fineAmountMin: (10 * UMA_2025).toFixed(2),
    fineAmountMax: (20 * UMA_2025).toFixed(2),
    points: 2,
    severity: "low",
    legalSteps: [
      "Solicitar boleta de infracción con clave y monto",
      "Verificar si hay descuento por pronto pago (50% en 5 días)",
      "Pagar en línea en SCT o ventanilla bancaria",
      "Si deseas inconformarte, tienes 15 días hábiles"
    ],
    canContest: true,
    contestProcess: "Presentar escrito de inconformidad ante la Unidad de Transporte más cercana con pruebas (GPS, tacógrafo)"
  },
  {
    code: "ART-24-II", 
    title: "Exceso de velocidad de 21 a 30 km/h",
    description: "Circular a velocidad mayor a la permitida entre 21 y 30 km/h",
    category: "speed",
    fineAmountMin: (20 * UMA_2025).toFixed(2),
    fineAmountMax: (30 * UMA_2025).toFixed(2),
    points: 4,
    severity: "medium",
    legalSteps: [
      "Solicitar boleta de infracción",
      "Verificar descuento por pronto pago",
      "Revisar si procede reducción de puntos con curso de educación vial",
      "Pagar o inconformarse en 15 días hábiles"
    ],
    canContest: true,
    contestProcess: "Presentar inconformidad con evidencia de velocímetro calibrado"
  },
  {
    code: "ART-24-III",
    title: "Exceso de velocidad mayor a 30 km/h",
    description: "Circular a velocidad mayor a la permitida, excediendo 30 km/h",
    category: "speed",
    fineAmountMin: (30 * UMA_2025).toFixed(2),
    fineAmountMax: (50 * UMA_2025).toFixed(2),
    points: 6,
    severity: "high",
    legalSteps: [
      "Infracción grave - posible remisión a corralón",
      "Solicitar boleta inmediatamente",
      "NO procede descuento en infracciones graves",
      "Revisar si hay retención de licencia",
      "Inconformarse en 15 días con asesoría legal recomendada"
    ],
    canContest: true,
    contestProcess: "Requiere asesoría legal - presentar calibración de radar y peritaje"
  },
  
  // DOCUMENTOS
  {
    code: "ART-56-I",
    title: "Circular sin licencia de conducir",
    description: "Conducir vehículo sin portar licencia vigente",
    category: "documents",
    fineAmountMin: (20 * UMA_2025).toFixed(2),
    fineAmountMax: (40 * UMA_2025).toFixed(2),
    points: 4,
    severity: "high",
    legalSteps: [
      "Vehículo será enviado a corralón",
      "Presentar licencia vigente para recuperar vehículo",
      "Pagar multa + costo de grúa + pensión de corralón",
      "Si no tienes licencia, tramitarla antes de recuperar vehículo"
    ],
    canContest: false,
    contestProcess: null
  },
  {
    code: "ART-56-II",
    title: "Circular sin tarjeta de circulación",
    description: "No portar tarjeta de circulación vigente del vehículo",
    category: "documents",
    fineAmountMin: (10 * UMA_2025).toFixed(2),
    fineAmountMax: (20 * UMA_2025).toFixed(2),
    points: 2,
    severity: "medium",
    legalSteps: [
      "Solicitar boleta de infracción",
      "Presentar tarjeta de circulación en Unidad de Transporte en 72 horas",
      "Si presentas documento, se cancela multa",
      "De lo contrario, pagar en 15 días"
    ],
    canContest: true,
    contestProcess: "Presentar tarjeta de circulación original en plazo de 72 horas"
  },
  {
    code: "ART-56-III",
    title: "Circular sin póliza de seguro vigente",
    description: "No contar con seguro de responsabilidad civil vigente",
    category: "documents",
    fineAmountMin: (30 * UMA_2025).toFixed(2),
    fineAmountMax: (50 * UMA_2025).toFixed(2),
    points: 6,
    severity: "severe",
    legalSteps: [
      "Infracción GRAVE - vehículo a corralón",
      "Contratar seguro inmediatamente",
      "Presentar póliza vigente para liberar vehículo",
      "Pagar multa + gastos de arrastre",
      "No aplica descuento por pronto pago"
    ],
    canContest: false,
    contestProcess: null
  },

  // CONDICIONES DEL VEHÍCULO
  {
    code: "ART-78-I",
    title: "Circular con llantas en mal estado",
    description: "Llantas lisas, desgastadas o dañadas que comprometan la seguridad",
    category: "vehicle_condition",
    fineAmountMin: (15 * UMA_2025).toFixed(2),
    fineAmountMax: (25 * UMA_2025).toFixed(2),
    points: 3,
    severity: "medium",
    legalSteps: [
      "Vehículo puede ser inmovilizado si es peligro inminente",
      "Cambiar llantas en el lugar o remolcar vehículo",
      "Pagar multa en 15 días",
      "Presentar evidencia de cambio de llantas para reducción de 30%"
    ],
    canContest: true,
    contestProcess: "Presentar verificación vehicular vigente o peritaje de llantas"
  },
  {
    code: "ART-78-II",
    title: "Luces no funcionan o están alteradas",
    description: "Circular sin luces, luces fundidas o con modificaciones no permitidas",
    category: "vehicle_condition",
    fineAmountMin: (10 * UMA_2025).toFixed(2),
    fineAmountMax: (20 * UMA_2025).toFixed(2),
    points: 3,
    severity: "medium",
    legalSteps: [
      "Reparar luces inmediatamente",
      "Si es de noche, vehículo será remolcado",
      "Pagar multa o presentar comprobante de reparación en 5 días para 40% descuento"
    ],
    canContest: true,
    contestProcess: "Presentar comprobante de reparación inmediata"
  },

  // REGLAS DE TRÁNSITO
  {
    code: "ART-32-I",
    title: "No respetar señalamiento ALTO",
    description: "No detenerse completamente en señal de ALTO",
    category: "traffic_rules",
    fineAmountMin: (15 * UMA_2025).toFixed(2),
    fineAmountMax: (20 * UMA_2025).toFixed(2),
    points: 4,
    severity: "medium",
    legalSteps: [
      "Solicitar boleta con evidencia fotográfica",
      "Descuento 50% en 5 días",
      "Revisar grabación de cámaras si las hay",
      "Inconformarse con testigos o dashcam"
    ],
    canContest: true,
    contestProcess: "Presentar video de dashcam o testigos"
  },
  {
    code: "ART-32-II",
    title: "Dar vuelta en U prohibida",
    description: "Realizar vuelta en U donde está prohibido",
    category: "traffic_rules",
    fineAmountMin: (10 * UMA_2025).toFixed(2),
    fineAmountMax: (15 * UMA_2025).toFixed(2),
    points: 2,
    severity: "low",
    legalSteps: [
      "Solicitar boleta",
      "Verificar señalamiento visible",
      "Descuento por pronto pago",
      "Si señal no es visible, procede inconformidad"
    ],
    canContest: true,
    contestProcess: "Fotografías que demuestren falta de señalamiento visible"
  },
  {
    code: "ART-45-I",
    title: "Rebasar en zona prohibida",
    description: "Adelantar otro vehículo en curva, puente, túnel o zona restringida",
    category: "traffic_rules",
    fineAmountMin: (25 * UMA_2025).toFixed(2),
    fineAmountMax: (40 * UMA_2025).toFixed(2),
    points: 5,
    severity: "high",
    legalSteps: [
      "Infracción grave - puede haber retención de licencia",
      "Revisar si hay video de patrulla",
      "No aplica descuento",
      "Asesoría legal recomendada para inconformidad"
    ],
    canContest: true,
    contestProcess: "Requiere peritaje vial y demostrar que no había restricción"
  },

  // ESTACIONAMIENTO
  {
    code: "ART-67-I",
    title: "Estacionarse en lugar prohibido",
    description: "Estacionar en zona de no estacionamiento, doble fila o acotamiento",
    category: "parking",
    fineAmountMin: (8 * UMA_2025).toFixed(2),
    fineAmountMax: (15 * UMA_2025).toFixed(2),
    points: 1,
    severity: "low",
    legalSteps: [
      "Si hay grúa, pagar arrastre adicional",
      "Solicitar boleta con ubicación exacta",
      "Descuento 50% en 5 días",
      "Revisar si señalamiento es claro"
    ],
    canContest: true,
    contestProcess: "Fotografías del lugar demostrando ausencia de señales"
  },

  // ALCOHOL Y DROGAS
  {
    code: "ART-91-I",
    title: "Conducir en estado de ebriedad",
    description: "Manejar bajo influencia del alcohol (0.4 a 0.8 g/l)",
    category: "alcohol",
    fineAmountMin: (50 * UMA_2025).toFixed(2),
    fineAmountMax: (100 * UMA_2025).toFixed(2),
    points: 10,
    severity: "severe",
    legalSteps: [
      "DELITO GRAVE - puede haber arresto hasta 36 horas",
      "Vehículo a corralón inmediato",
      "Licencia suspendida de 6 meses a 2 años",
      "Requiere abogado especializado",
      "Posible sentencia penal si hay daños"
    ],
    canContest: true,
    contestProcess: "Solo con abogado - impugnar prueba de alcoholímetro si no fue calibrado"
  },
  {
    code: "ART-91-II",
    title: "Conducir en estado de ebriedad grave",
    description: "Manejar bajo influencia del alcohol (más de 0.8 g/l)",
    category: "alcohol",
    fineAmountMin: (100 * UMA_2025).toFixed(2),
    fineAmountMax: (150 * UMA_2025).toFixed(2),
    points: 12,
    severity: "severe",
    legalSteps: [
      "DELITO FEDERAL GRAVE",
      "Arresto inmediato hasta 72 horas",
      "Vehículo decomisado",
      "Licencia cancelada 2-5 años",
      "Requiere fianza y abogado penalista",
      "Antecedentes penales permanentes"
    ],
    canContest: true,
    contestProcess: "Solo con abogado penalista - proceso judicial completo"
  },

  // LICENCIA
  {
    code: "ART-102-I",
    title: "Conducir con licencia vencida",
    description: "Portar licencia de conducir expirada",
    category: "license",
    fineAmountMin: (15 * UMA_2025).toFixed(2),
    fineAmountMax: (25 * UMA_2025).toFixed(2),
    points: 3,
    severity: "medium",
    legalSteps: [
      "Renovar licencia inmediatamente",
      "Si renuevas en 72 horas y presentas comprobante, descuento 60%",
      "De lo contrario, pagar en 15 días",
      "Posible retención de vehículo si excede 6 meses vencida"
    ],
    canContest: false,
    contestProcess: null
  },
  {
    code: "ART-102-II",
    title: "Conducir con licencia suspendida",
    description: "Manejar con licencia legalmente suspendida",
    category: "license",
    fineAmountMin: (40 * UMA_2025).toFixed(2),
    fineAmountMax: (80 * UMA_2025).toFixed(2),
    points: 8,
    severity: "severe",
    legalSteps: [
      "Vehículo a corralón inmediato",
      "Posible arresto administrativo",
      "Extensión de suspensión por 1 año adicional",
      "Requiere asesoría legal para reactivación",
      "No aplica descuento ni inconformidad"
    ],
    canContest: false,
    contestProcess: null
  },

  // TRACTOCAMIONES Y CARGA
  {
    code: "ART-115-I",
    title: "Exceso de peso en tractocamión",
    description: "Circular con peso superior al permitido según número de ejes",
    category: "vehicle_condition",
    fineAmountMin: (60 * UMA_2025).toFixed(2),
    fineAmountMax: (120 * UMA_2025).toFixed(2),
    points: 8,
    severity: "severe",
    legalSteps: [
      "Vehículo detenido hasta descargar excedente",
      "Multa por cada tonelada excedida",
      "Báscula oficial determinará peso real",
      "Empresa transportista es responsable solidaria",
      "Posible cancelación de permiso SCT si es reincidente"
    ],
    canContest: true,
    contestProcess: "Solicitar re-pesaje en báscula certificada oficial"
  },
  {
    code: "ART-115-II",
    title: "Circular sin permiso SCT vigente",
    description: "Tractocamión sin permiso federal de la SCT",
    category: "documents",
    fineAmountMin: (80 * UMA_2025).toFixed(2),
    fineAmountMax: (150 * UMA_2025).toFixed(2),
    points: 10,
    severity: "severe",
    legalSteps: [
      "Decomiso inmediato de vehículo y carga",
      "Multa federal grave",
      "Tramitar permiso antes de liberar vehículo",
      "Costo de almacenaje de carga por día",
      "Posible sanción a empresa transportista"
    ],
    canContest: false,
    contestProcess: null
  },
  {
    code: "ART-115-III",
    title: "Dimensiones excedidas en tractocamión",
    description: "Ancho, alto o largo excede dimensiones permitidas",
    category: "vehicle_condition",
    fineAmountMin: (40 * UMA_2025).toFixed(2),
    fineAmountMax: (80 * UMA_2025).toFixed(2),
    points: 6,
    severity: "high",
    legalSteps: [
      "Vehículo detenido hasta ajustar carga",
      "Requiere permiso especial de sobrepeso/sobredimensión",
      "Multa + costo de escolta si procede",
      "Si no puede ajustarse, transferir carga a otro vehículo"
    ],
    canContest: true,
    contestProcess: "Presentar permiso especial de SCT para carga sobredimensionada"
  }
];

async function seedInfractions() {
  try {
    console.log("🚨 Insertando infracciones del RTCPJF 2025...");
    
    for (const infraction of infractionData) {
      await db.insert(infractions).values({
        ...infraction,
        category: infraction.category as any,
        severity: infraction.severity as any
      }).onConflictDoNothing();
    }
    
    console.log(`✅ ${infractionData.length} infracciones insertadas exitosamente`);
    console.log(`💰 UMA 2025 utilizada: $${UMA_2025} MXN`);
    process.exit(0);
  } catch (error) {
    console.error("❌ Error insertando infracciones:", error);
    process.exit(1);
  }
}

seedInfractions();

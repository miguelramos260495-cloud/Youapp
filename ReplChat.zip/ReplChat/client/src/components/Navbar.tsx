import { Shield, Menu, MapPin, Building2, Route as RouteIcon, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "wouter";
import { Separator } from "@/components/ui/separator";

export function Navbar() {
  const { user } = useAuth();
  const [location] = useLocation();

  const isAdmin = user?.email === "miguelramos260495@gmail.com";

  const navItems = user?.userType === 'company' 
    ? [
        { href: "/company", label: "Dashboard", icon: Building2 },
        { href: "/", label: "Navegación", icon: MapPin },
        { href: "/trips", label: "Bitácora", icon: Shield },
        { href: "/alerts", label: "Alertas", icon: Shield },
        { href: "/reports", label: "Reportes", icon: Shield },
        { href: "/places", label: "Servicios", icon: Shield },
        { href: "/profile", label: "Perfil", icon: Shield },
        ...(isAdmin ? [{ href: "/admin", label: "Administración", icon: Settings }] : []),
      ]
    : [
        { href: "/", label: "Navegación", icon: MapPin },
        { href: "/trips", label: "Bitácora", icon: Shield },
        { href: "/alerts", label: "Alertas", icon: Shield },
        { href: "/reports", label: "Reportes", icon: Shield },
        { href: "/places", label: "Servicios", icon: Shield },
        { href: "/tourist-routes", label: "Rutas Turísticas", icon: RouteIcon },
        { href: "/profile", label: "Perfil", icon: Shield },
        ...(isAdmin ? [{ href: "/admin", label: "Administración", icon: Settings }] : []),
      ];

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    return user?.email?.[0]?.toUpperCase() || "U";
  };

  return (
    <nav className="sticky top-0 z-40 h-16 bg-[#1c1e2e] border-b border-border backdrop-blur-sm">
      <div className="h-full px-4 flex items-center justify-between max-w-7xl mx-auto">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-gradient-to-br from-primary to-primary/80">
            <Shield className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="font-bold text-xl hidden sm:inline">Sobre la Vía</span>
        </Link>

        {/* Current Location (Center) */}
        <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="w-4 h-4" />
          <span className="max-w-[200px] truncate">Ciudad de México, México</span>
        </div>

        {/* Menu */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" data-testid="button-menu">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-80">
            <SheetHeader>
              <SheetTitle className="text-left">
                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={user?.profileImageUrl || ""} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {getInitials()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">
                      {user?.firstName && user?.lastName
                        ? `${user.firstName} ${user.lastName}`
                        : user?.email || "Usuario"}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {user?.userType === "company" ? "Empresa" : "Conductor"}
                    </div>
                  </div>
                </div>
              </SheetTitle>
            </SheetHeader>

            <Separator className="my-4" />

            <nav className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                return (
                  <Link key={item.href} href={item.href}>
                    <a
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg hover-elevate active-elevate-2 transition-colors ${
                        isActive ? "bg-primary/10 text-primary" : "text-foreground"
                      }`}
                      data-testid={`link-${item.href.replace('/', '') || 'home'}`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </a>
                  </Link>
                );
              })}
            </nav>

            <Separator className="my-4" />

            <Button
              variant="outline"
              className="w-full"
              onClick={() => (window.location.href = "/api/logout")}
              data-testid="button-logout"
            >
              Cerrar Sesión
            </Button>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}

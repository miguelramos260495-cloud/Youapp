import { Switch, Route } from "wouter";
import { useState, useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useMutation } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { PanicButton } from "@/components/PanicButton";
import QuickReportButton from "@/components/QuickReportButton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Navigation from "@/pages/Navigation";
import Trips from "@/pages/Trips";
import Alerts from "@/pages/Alerts";
import Reports from "@/pages/Reports";
import Places from "@/pages/Places";
import Profile from "@/pages/Profile";
import CompanyDashboard from "@/pages/CompanyDashboard";
import TouristRoutes from "@/pages/TouristRoutes";
import LegalServices from "@/pages/LegalServices";
import Admin from "@/pages/Admin";

type AlertType = "robbery" | "legal" | "medical" | "safe_travel";

function Router() {
  const { isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/" component={Navigation} />
      <Route path="/trips" component={Trips} />
      <Route path="/alerts" component={Alerts} />
      <Route path="/reports" component={Reports} />
      <Route path="/places" component={Places} />
      <Route path="/tourist-routes" component={TouristRoutes} />
      <Route path="/legal-services" component={LegalServices} />
      <Route path="/profile" component={Profile} />
      <Route path="/company" component={CompanyDashboard} />
      <Route path="/admin" component={Admin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  // Track user location globally
  useEffect(() => {
    if (!isAuthenticated) return;
    
    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        setUserLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (error) => {
        console.error("Error getting location:", error);
      },
      { enableHighAccuracy: true, maximumAge: 10000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [isAuthenticated]);

  const createAlertMutation = useMutation({
    mutationFn: async (data: {
      type: AlertType;
      latitude: number;
      longitude: number;
      location: string;
      evidenceUrls?: string[];
    }) => {
      return await apiRequest("POST", "/api/alerts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "Alerta Activada",
        description: "Tus contactos de emergencia han sido notificados",
        variant: "default",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo activar la alerta. Intenta de nuevo.",
        variant: "destructive",
      });
    },
  });

  const blobToDataURL = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const handleAlert = async (type: AlertType, location: { lat: number; lng: number }, evidenceBlobs?: Blob[]) => {
    let evidenceUrls: string[] | undefined;
    if (evidenceBlobs && evidenceBlobs.length > 0) {
      evidenceUrls = await Promise.all(
        evidenceBlobs.map(blob => blobToDataURL(blob))
      );
    }

    createAlertMutation.mutate({
      type,
      latitude: location.lat,
      longitude: location.lng,
      location: `${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}`,
      evidenceUrls,
    });
  };

  return (
    <TooltipProvider>
      {!isLoading && <Navbar />}
      <Toaster />
      <Router />
      {!isLoading && user?.userType !== 'company' && (
        <>
          <QuickReportButton userLocation={userLocation} />
          <PanicButton onAlert={handleAlert} />
        </>
      )}
    </TooltipProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  );
}

export default App;

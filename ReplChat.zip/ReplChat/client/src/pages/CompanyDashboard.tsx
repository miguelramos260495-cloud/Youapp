import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Building2,
  Users,
  MapPin,
  Route,
  MessageSquare,
  AlertTriangle,
  Calendar,
  IdCard,
  Send,
  Mail,
  Phone,
} from "lucide-react";
import type { User, Trip, Message, Route as RouteType } from "@shared/schema";

export default function CompanyDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedDriver, setSelectedDriver] = useState<User | null>(null);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [tripDetailsDialogOpen, setTripDetailsDialogOpen] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const [messagePriority, setMessagePriority] = useState<"normal" | "high" | "urgent">("normal");
  const [vehicleOptionsDialogOpen, setVehicleOptionsDialogOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<any | null>(null);

  const { data: drivers = [], isLoading: driversLoading } = useQuery<User[]>({
    queryKey: ["/api/company/drivers"],
    enabled: user?.userType === 'company',
  });

  const { data: allTrips = [] } = useQuery<Trip[]>({
    queryKey: ["/api/company/trips"],
  });

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
  });

  const { data: companyRoutes = [] } = useQuery<RouteType[]>({
    queryKey: ["/api/company/routes"],
    enabled: user?.userType === 'company',
  });

  const { data: companyVehicles = [] } = useQuery<any[]>({
    queryKey: ["/api/company/vehicles"],
    enabled: user?.userType === 'company',
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { receiverId: string; content: string; priority: string; type: string }) => {
      return await apiRequest("POST", "/api/messages", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      toast({
        title: "Mensaje enviado",
        description: "El chofer recibirá tu mensaje",
      });
      setMessageDialogOpen(false);
      setMessageContent("");
      setMessagePriority("normal");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!selectedDriver || !messageContent.trim()) {
      toast({
        title: "Campos requeridos",
        description: "Escribe un mensaje antes de enviar",
        variant: "destructive",
      });
      return;
    }

    sendMessageMutation.mutate({
      receiverId: selectedDriver.id,
      content: messageContent,
      priority: messagePriority,
      type: "message",
    });
  };

  const openMessageDialog = (driver: User) => {
    setSelectedDriver(driver);
    setMessageDialogOpen(true);
  };

  const openTripDetails = (trip: Trip) => {
    setSelectedTrip(trip);
    setTripDetailsDialogOpen(true);
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    const first = firstName?.charAt(0) || '';
    const last = lastName?.charAt(0) || '';
    return (first + last).toUpperCase() || 'U';
  };

  const formatDate = (date: string | Date | null | undefined) => {
    if (!date) return 'No especificada';
    return new Date(date).toLocaleDateString('es-MX', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isLicenseExpiringSoon = (expiryDate: string | Date | null | undefined) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const daysUntilExpiry = Math.floor((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30 && daysUntilExpiry >= 0;
  };

  if (user?.userType !== 'company') {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <Card className="p-8 text-center">
          <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold mb-2">Acceso Restringido</h2>
          <p className="text-muted-foreground">Esta página es solo para cuentas empresariales</p>
        </Card>
      </div>
    );
  }

  if (driversLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando dashboard...</p>
        </div>
      </div>
    );
  }

  const activeTrips = allTrips.filter(t => t.status === 'active');
  const completedTrips = allTrips.filter(t => t.status === 'completed');

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-start gap-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20">
            <Building2 className="w-12 h-12 text-blue-500" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Dashboard Empresarial</h1>
            <p className="text-muted-foreground">
              Gestiona tus choferes, bitácoras y ubicaciones en tiempo real
            </p>
          </div>
        </div>

        {/* Estadísticas Generales */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-lg bg-blue-500/10">
                <Users className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold" data-testid="text-total-drivers">{drivers.length}</p>
                <p className="text-sm text-muted-foreground">Choferes</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-lg bg-green-500/10">
                <Route className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold" data-testid="text-active-trips">{activeTrips.length}</p>
                <p className="text-sm text-muted-foreground">Viajes Activos</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-lg bg-purple-500/10">
                <Calendar className="w-6 h-6 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold" data-testid="text-completed-trips">{completedTrips.length}</p>
                <p className="text-sm text-muted-foreground">Completados</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-lg bg-orange-500/10">
                <MessageSquare className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold" data-testid="text-total-messages">{messages.length}</p>
                <p className="text-sm text-muted-foreground">Mensajes</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Flota de Vehículos */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Car className="w-5 h-5" />
            Flota de Vehículos
          </h2>
          
          {companyVehicles.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Car className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">No hay vehículos registrados</p>
              <p className="text-sm mt-2">Registra los vehículos de tu flota</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {companyVehicles.map((vehicle) => {
                const vehicleTrip = allTrips.find(t => t.vehicleId === vehicle.id && t.status === 'active');
                const isInMotion = !!vehicleTrip;
                
                return (
                  <Card 
                    key={vehicle.id} 
                    className="p-4 hover-elevate cursor-pointer" 
                    data-testid={`vehicle-card-${vehicle.id}`}
                    onDoubleClick={() => {
                      setSelectedVehicle(vehicle);
                      setVehicleOptionsDialogOpen(true);
                    }}
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div className={`p-3 rounded-lg ${isInMotion ? 'bg-blue-500/10' : 'bg-gray-500/10'}`}>
                        <Car className={`w-6 h-6 ${isInMotion ? 'text-blue-500' : 'text-gray-500'}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate text-black dark:text-white">
                          {vehicle.brand} {vehicle.model}
                        </h3>
                        <p className="text-sm text-black dark:text-white">{vehicle.plate}</p>
                        {isInMotion ? (
                          <Badge className="mt-1 bg-blue-500 hover:bg-blue-600 text-white">
                            <MapPin className="w-3 h-3 mr-1" />
                            En movimiento
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="mt-1">Detenido</Badge>
                        )}
                      </div>
                    </div>

                    <Separator className="my-3" />

                    <div className="space-y-2 text-sm">
                      {vehicle.type && (
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Tipo:</span>
                          <span className="text-black dark:text-white capitalize">{vehicle.type}</span>
                        </div>
                      )}
                      {vehicle.year && (
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Año:</span>
                          <span className="text-black dark:text-white">{vehicle.year}</span>
                        </div>
                      )}
                      {vehicleTrip && (
                        <div className="flex items-center gap-2 text-xs bg-yellow-500/10 p-2 rounded-md mt-2">
                          <Route className="w-3 h-3 text-yellow-600 dark:text-yellow-500" />
                          <span className="text-black dark:text-white truncate">
                            {vehicleTrip.startLocation} → <span className="text-red-600 dark:text-red-500 font-semibold">{vehicleTrip.endLocation || 'En ruta'}</span>
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="mt-3 text-xs text-center text-muted-foreground">
                      Doble click para opciones
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </Card>

        {/* Lista de Choferes */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Users className="w-5 h-5" />
            Choferes Activos
          </h2>
          
          {drivers.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">No hay choferes registrados</p>
              <p className="text-sm mt-2">Los choferes deben asociarse a tu empresa</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {drivers.map((driver) => {
                const driverTrips = allTrips.filter(t => t.userId === driver.id);
                const activeTrip = driverTrips.find(t => t.status === 'active');
                
                return (
                  <Card key={driver.id} className="p-4 hover-elevate" data-testid={`driver-card-${driver.id}`}>
                    <div className="flex items-start gap-3 mb-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={driver.profileImageUrl || undefined} />
                        <AvatarFallback>{getInitials(driver.firstName || undefined, driver.lastName || undefined)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate" data-testid={`driver-name-${driver.id}`}>
                          {driver.firstName} {driver.lastName}
                        </h3>
                        {activeTrip ? (
                          <Badge variant="default" className="mt-1">
                            <MapPin className="w-3 h-3 mr-1" />
                            En viaje
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="mt-1">Disponible</Badge>
                        )}
                      </div>
                    </div>

                    <Separator className="my-3" />

                    <div className="space-y-2 text-sm">
                      {driver.email && (
                        <div className="flex items-center gap-2 text-black dark:text-white">
                          <Mail className="w-4 h-4" />
                          <span className="truncate">{driver.email}</span>
                        </div>
                      )}
                      {driver.phone && (
                        <div className="flex items-center gap-2 text-black dark:text-white">
                          <Phone className="w-4 h-4" />
                          <span>{driver.phone}</span>
                        </div>
                      )}
                      {driver.licenseNumber && (
                        <div className="flex items-center gap-2 text-black dark:text-white">
                          <IdCard className="w-4 h-4" />
                          <span>Lic. {driver.licenseNumber}</span>
                          {isLicenseExpiringSoon(driver.licenseExpiry) && (
                            <AlertTriangle className="w-4 h-4 text-orange-500" />
                          )}
                        </div>
                      )}
                    </div>

                    <Separator className="my-3" />

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {driverTrips.length} viajes totales
                      </span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openMessageDialog(driver)}
                        data-testid={`button-message-${driver.id}`}
                      >
                        <MessageSquare className="w-4 h-4 mr-1" />
                        Mensaje
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </Card>

        {/* Viajes Activos */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Route className="w-5 h-5" />
            Viajes en Curso
          </h2>
          
          {activeTrips.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Route className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No hay viajes activos en este momento</p>
            </div>
          ) : (
            <div className="space-y-3">
              {activeTrips.map((trip) => {
                const driver = drivers.find(d => d.id === trip.userId);
                
                return (
                  <div
                    key={trip.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover-elevate active-elevate-2 cursor-pointer"
                    onClick={() => openTripDetails(trip)}
                    data-testid={`active-trip-${trip.id}`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {driver && (
                          <span className="font-medium text-black dark:text-white">{driver.firstName} {driver.lastName}</span>
                        )}
                        <span className="text-black dark:text-white">•</span>
                        <span className="text-black dark:text-white">{trip.driverName || 'Sin conductor'}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-medium text-black dark:text-white">{trip.startLocation}</span>
                        <span className="text-black dark:text-white">→</span>
                        <span className="font-medium text-black dark:text-white">{trip.endLocation || 'Destino no definido'}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-black dark:text-white mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(trip.startTime)}
                        </span>
                        {trip.roadType && (
                          <Badge variant="outline" className="text-xs">
                            {trip.roadType === 'federal' ? 'Federal' : trip.roadType === 'state' ? 'Estatal' : 'Municipal'}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      Ver detalles →
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Rutas Empresariales */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Route className="w-5 h-5" />
              Rutas Empresariales
            </h2>
            <Button variant="default" size="sm" data-testid="button-create-route">
              Crear Ruta
            </Button>
          </div>

          {companyRoutes.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Route className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No hay rutas creadas para tu empresa</p>
              <p className="text-sm mt-2">Crea rutas personalizadas para tus choferes</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {companyRoutes.map((route) => (
                <Card key={route.id} className="p-4 hover-elevate" data-testid={`route-card-${route.id}`}>
                  <h3 className="font-semibold mb-2" data-testid={`route-name-${route.id}`}>
                    {route.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-3">{route.description}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-navigation-blue" />
                      <span>{route.startPoint} → {route.endPoint}</span>
                    </div>
                    
                    {route.estimatedDuration && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-navigation-blue" />
                        <span>{route.estimatedDuration}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 mt-3">
                    {route.isPublic ? (
                      <Badge variant="secondary">Pública</Badge>
                    ) : (
                      <Badge variant="outline">Privada</Badge>
                    )}
                    <Badge variant="outline">{route.routeType}</Badge>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </Card>

        {/* Modal de Mensaje */}
        <Dialog open={messageDialogOpen} onOpenChange={setMessageDialogOpen}>
          <DialogContent data-testid="message-dialog">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Enviar Mensaje
              </DialogTitle>
              <DialogDescription>
                Enviar mensaje a {selectedDriver?.firstName} {selectedDriver?.lastName}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Prioridad</label>
                <Select value={messagePriority} onValueChange={(value: any) => setMessagePriority(value)}>
                  <SelectTrigger data-testid="select-message-priority">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                    <SelectItem value="urgent">Urgente</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Mensaje</label>
                <Textarea
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                  placeholder="Escribe tu mensaje aquí..."
                  rows={4}
                  data-testid="textarea-message"
                />
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setMessageDialogOpen(false)}
                data-testid="button-cancel-message"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSendMessage}
                disabled={sendMessageMutation.isPending || !messageContent.trim()}
                data-testid="button-send-message"
              >
                <Send className="w-4 h-4 mr-2" />
                Enviar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Modal de Detalles de Viaje */}
        <Dialog open={tripDetailsDialogOpen} onOpenChange={setTripDetailsDialogOpen}>
          <DialogContent className="max-w-2xl" data-testid="trip-details-dialog">
            <DialogHeader>
              <DialogTitle>Detalles del Viaje</DialogTitle>
            </DialogHeader>

            {selectedTrip && (
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Conductor</p>
                    <p className="font-medium">{selectedTrip.driverName || 'No especificado'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Licencia</p>
                    <p className="font-medium">{selectedTrip.driverLicense || 'No especificada'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Origen</p>
                    <p className="font-medium">{selectedTrip.startLocation}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Destino</p>
                    <p className="font-medium">{selectedTrip.endLocation || 'En definición'}</p>
                  </div>
                  {selectedTrip.cargoType && (
                    <div>
                      <p className="text-sm text-muted-foreground">Tipo de Carga</p>
                      <p className="font-medium">{selectedTrip.cargoType}</p>
                    </div>
                  )}
                  {selectedTrip.cargoWeight && (
                    <div>
                      <p className="text-sm text-muted-foreground">Peso (ton)</p>
                      <p className="font-medium">{selectedTrip.cargoWeight}</p>
                    </div>
                  )}
                  {selectedTrip.startOdometer && (
                    <div>
                      <p className="text-sm text-muted-foreground">Odómetro Inicial</p>
                      <p className="font-medium">{selectedTrip.startOdometer} km</p>
                    </div>
                  )}
                  {selectedTrip.distance && (
                    <div>
                      <p className="text-sm text-muted-foreground">Distancia Recorrida</p>
                      <p className="font-medium">{selectedTrip.distance.toFixed(1)} km</p>
                    </div>
                  )}
                </div>

                {selectedTrip.isDangerousMaterial && (
                  <Card className="p-4 border-orange-500/50 bg-orange-500/5">
                    <div className="flex items-center gap-2 text-orange-500 mb-2">
                      <AlertTriangle className="w-5 h-5" />
                      <p className="font-semibold">Material Peligroso</p>
                    </div>
                    <div className="space-y-1 text-sm">
                      <p><strong>Clase:</strong> {selectedTrip.dangerousMaterialClass}</p>
                      {selectedTrip.dangerousMaterialDescription && (
                        <p><strong>Descripción:</strong> {selectedTrip.dangerousMaterialDescription}</p>
                      )}
                      <p>
                        <strong>Inspección Visual:</strong>{' '}
                        {selectedTrip.visualInspectionCompleted ? '✅ Completada' : '❌ Pendiente'}
                      </p>
                    </div>
                  </Card>
                )}
              </div>
            )}

            <DialogFooter>
              <Button onClick={() => setTripDetailsDialogOpen(false)} data-testid="button-close-trip-details">
                Cerrar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Modal de Opciones de Vehículo */}
        <Dialog open={vehicleOptionsDialogOpen} onOpenChange={setVehicleOptionsDialogOpen}>
          <DialogContent data-testid="vehicle-options-dialog">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Car className="w-5 h-5" />
                Opciones de Vehículo
              </DialogTitle>
              <DialogDescription>
                {selectedVehicle && `${selectedVehicle.brand} ${selectedVehicle.model} - ${selectedVehicle.plate}`}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3 py-4">
              <Button 
                className="w-full justify-start" 
                variant="outline" 
                size="lg"
                onClick={() => {
                  setVehicleOptionsDialogOpen(false);
                  toast({
                    title: "Cambiar Destino",
                    description: "Funcionalidad en desarrollo",
                  });
                }}
                data-testid="button-change-destination"
              >
                <MapPin className="w-5 h-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Cambiar Destino</p>
                  <p className="text-xs text-muted-foreground">Actualizar la ruta del vehículo</p>
                </div>
              </Button>

              <Button 
                className="w-full justify-start" 
                variant="outline" 
                size="lg"
                onClick={() => {
                  const vehicleTrip = allTrips.find(t => t.vehicleId === selectedVehicle?.id && t.status === 'active');
                  if (vehicleTrip) {
                    const driver = drivers.find(d => d.id === vehicleTrip.userId);
                    if (driver) {
                      setSelectedDriver(driver);
                      setVehicleOptionsDialogOpen(false);
                      setMessageDialogOpen(true);
                    } else {
                      toast({
                        title: "Error",
                        description: "No se encontró el conductor",
                        variant: "destructive",
                      });
                    }
                  } else {
                    toast({
                      title: "Vehículo sin conductor",
                      description: "Este vehículo no está asignado a ningún viaje activo",
                      variant: "destructive",
                    });
                  }
                }}
                data-testid="button-send-message-vehicle"
              >
                <MessageSquare className="w-5 h-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Enviar Mensaje</p>
                  <p className="text-xs text-muted-foreground">Comunicarse con el conductor</p>
                </div>
              </Button>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setVehicleOptionsDialogOpen(false)}>
                Cancelar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

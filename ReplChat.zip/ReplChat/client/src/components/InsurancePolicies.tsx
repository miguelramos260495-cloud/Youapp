import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Shield, Plus, Trash2, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { InsurancePolicy } from "@shared/schema";

export default function InsurancePolicies() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [policyToDelete, setPolicyToDelete] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    insuranceCompany: "",
    policyNumber: "",
    phoneNumber: "",
    emergencyPhone: "",
    coverageType: "liability" as "liability" | "comprehensive" | "collision" | "third_party",
    coverageAmount: "",
    startDate: "",
    endDate: "",
    vehicleId: "",
    notes: "",
  });

  const { data: policies = [], isLoading } = useQuery<InsurancePolicy[]>({
    queryKey: ["/api/insurance-policies"],
  });

  const { data: expiringPolicies = [] } = useQuery<InsurancePolicy[]>({
    queryKey: ["/api/insurance-policies/expiring"],
  });

  const { data: vehicles = [] } = useQuery<any[]>({
    queryKey: ["/api/vehicles"],
  });

  const addPolicyMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/insurance-policies", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/insurance-policies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/insurance-policies/expiring"] });
      toast({
        title: "Póliza agregada",
        description: "La póliza de seguro fue registrada correctamente",
      });
      setIsAddDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo agregar la póliza",
        variant: "destructive",
      });
    },
  });

  const deletePolicyMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/insurance-policies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/insurance-policies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/insurance-policies/expiring"] });
      toast({
        title: "Póliza eliminada",
        description: "La póliza fue eliminada correctamente",
      });
      setPolicyToDelete(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo eliminar la póliza",
        variant: "destructive",
      });
      setPolicyToDelete(null);
    },
  });

  const handleDeleteConfirm = () => {
    if (policyToDelete) {
      deletePolicyMutation.mutate(policyToDelete);
    }
  };

  const resetForm = () => {
    setFormData({
      insuranceCompany: "",
      policyNumber: "",
      phoneNumber: "",
      emergencyPhone: "",
      coverageType: "liability",
      coverageAmount: "",
      startDate: "",
      endDate: "",
      vehicleId: "",
      notes: "",
    });
  };

  const handleSubmit = () => {
    if (!formData.insuranceCompany || !formData.policyNumber || !formData.startDate || !formData.endDate) {
      toast({
        title: "Campos requeridos",
        description: "Completa todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    const payload: any = {
      insuranceCompany: formData.insuranceCompany,
      policyNumber: formData.policyNumber,
      phoneNumber: formData.phoneNumber || "",
      emergencyPhone: formData.emergencyPhone || null,
      coverageType: formData.coverageType,
      coverageAmount: formData.coverageAmount || null,
      startDate: formData.startDate,
      endDate: formData.endDate,
      notes: formData.notes || null,
      status: "active",
    };

    // Only include vehicleId if it's not empty
    if (formData.vehicleId) {
      payload.vehicleId = formData.vehicleId;
    }

    addPolicyMutation.mutate(payload);
  };

  const getStatusBadge = (status: string | null) => {
    if (!status) return null;
    const variants: any = {
      active: "default",
      expired: "destructive",
      cancelled: "secondary",
    };
    return <Badge variant={variants[status] || "secondary"}>{status}</Badge>;
  };

  const getCoverageTypeLabel = (type: string) => {
    const labels: any = {
      liability: "Responsabilidad Civil",
      comprehensive: "Cobertura Amplia",
      collision: "Colisión",
      third_party: "Terceros",
    };
    return labels[type] || type;
  };

  const getDaysUntilExpiry = (endDate: string | Date) => {
    const endDateObj = typeof endDate === 'string' ? new Date(endDate) : endDate;
    const days = Math.ceil(
      (endDateObj.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
    );
    return days;
  };

  return (
    <div className="space-y-6">
      {expiringPolicies.length > 0 && (
        <Card className="border-orange-500/50 bg-orange-500/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <AlertTriangle className="h-5 w-5" />
              Pólizas por Vencer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {expiringPolicies.map((policy) => (
              <div
                key={policy.id}
                className="p-3 rounded-lg bg-background border"
                data-testid={`expiring-policy-${policy.id}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium">{policy.insuranceCompany}</p>
                    <p className="text-sm text-muted-foreground">
                      Póliza: {policy.policyNumber}
                    </p>
                    <p className="text-sm text-orange-600 font-medium mt-1">
                      Vence en {getDaysUntilExpiry(policy.endDate)} días
                    </p>
                  </div>
                  {getStatusBadge(policy.status)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-500" />
              Pólizas de Seguro
            </CardTitle>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" data-testid="button-add-policy">
                  <Plus className="h-4 w-4 mr-2" />
                  Agregar Póliza
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Nueva Póliza de Seguro</DialogTitle>
                  <DialogDescription>
                    Registra una nueva póliza de seguro
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="insuranceCompany">Aseguradora *</Label>
                      <Input
                        id="insuranceCompany"
                        value={formData.insuranceCompany}
                        onChange={(e) =>
                          setFormData({ ...formData, insuranceCompany: e.target.value })
                        }
                        placeholder="Nombre de la aseguradora"
                        data-testid="input-insurance-company"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="policyNumber">Número de Póliza *</Label>
                      <Input
                        id="policyNumber"
                        value={formData.policyNumber}
                        onChange={(e) =>
                          setFormData({ ...formData, policyNumber: e.target.value })
                        }
                        placeholder="Número de póliza"
                        data-testid="input-policy-number"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phoneNumber">Teléfono</Label>
                      <Input
                        id="phoneNumber"
                        value={formData.phoneNumber}
                        onChange={(e) =>
                          setFormData({ ...formData, phoneNumber: e.target.value })
                        }
                        placeholder="Teléfono de contacto"
                        data-testid="input-phone-number"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="emergencyPhone">Teléfono de Emergencia</Label>
                      <Input
                        id="emergencyPhone"
                        value={formData.emergencyPhone}
                        onChange={(e) =>
                          setFormData({ ...formData, emergencyPhone: e.target.value })
                        }
                        placeholder="Teléfono de emergencias"
                        data-testid="input-emergency-phone"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="coverageType">Tipo de Cobertura *</Label>
                      <Select
                        value={formData.coverageType}
                        onValueChange={(value: any) =>
                          setFormData({ ...formData, coverageType: value })
                        }
                      >
                        <SelectTrigger id="coverageType" data-testid="select-coverage-type">
                          <SelectValue placeholder="Selecciona tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="liability">Responsabilidad Civil</SelectItem>
                          <SelectItem value="comprehensive">Cobertura Amplia</SelectItem>
                          <SelectItem value="collision">Colisión</SelectItem>
                          <SelectItem value="third_party">Terceros</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="coverageAmount">Suma Asegurada (MXN)</Label>
                      <Input
                        id="coverageAmount"
                        type="number"
                        value={formData.coverageAmount}
                        onChange={(e) =>
                          setFormData({ ...formData, coverageAmount: e.target.value })
                        }
                        placeholder="0.00"
                        data-testid="input-coverage-amount"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Fecha de Inicio *</Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={formData.startDate}
                        onChange={(e) =>
                          setFormData({ ...formData, startDate: e.target.value })
                        }
                        data-testid="input-start-date"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="endDate">Fecha de Vencimiento *</Label>
                      <Input
                        id="endDate"
                        type="date"
                        value={formData.endDate}
                        onChange={(e) =>
                          setFormData({ ...formData, endDate: e.target.value })
                        }
                        data-testid="input-end-date"
                      />
                    </div>
                  </div>

                  {vehicles.length > 0 && (
                    <div className="space-y-2">
                      <Label htmlFor="vehicleId">Vehículo (Opcional)</Label>
                      <Select
                        value={formData.vehicleId}
                        onValueChange={(value) =>
                          setFormData({ ...formData, vehicleId: value })
                        }
                      >
                        <SelectTrigger id="vehicleId" data-testid="select-vehicle">
                          <SelectValue placeholder="Selecciona un vehículo" />
                        </SelectTrigger>
                        <SelectContent>
                          {vehicles.map((vehicle) => (
                            <SelectItem key={vehicle.id} value={vehicle.id}>
                              {vehicle.type} - {vehicle.plate}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notas</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) =>
                        setFormData({ ...formData, notes: e.target.value })
                      }
                      placeholder="Notas adicionales..."
                      data-testid="input-notes"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                    data-testid="button-cancel"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={addPolicyMutation.isPending}
                    data-testid="button-submit-policy"
                  >
                    {addPolicyMutation.isPending ? "Guardando..." : "Guardar Póliza"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Cargando pólizas...</p>
          ) : policies.length === 0 ? (
            <p className="text-sm text-muted-foreground" data-testid="text-no-policies">
              No hay pólizas registradas. Agrega tu primera póliza de seguro.
            </p>
          ) : (
            <div className="space-y-3">
              {policies.map((policy) => (
                <div
                  key={policy.id}
                  className="p-4 rounded-lg border hover-elevate"
                  data-testid={`policy-card-${policy.id}`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium" data-testid={`text-company-${policy.id}`}>
                          {policy.insuranceCompany}
                        </p>
                        {getStatusBadge(policy.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Póliza: {policy.policyNumber}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {getCoverageTypeLabel(policy.coverageType)}
                        {policy.coverageAmount && ` - $${policy.coverageAmount.toLocaleString()} MXN`}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Vigencia: {new Date(policy.startDate).toLocaleDateString()} -{" "}
                        {new Date(policy.endDate).toLocaleDateString()}
                      </p>
                      {policy.phoneNumber && (
                        <p className="text-sm text-muted-foreground">
                          Teléfono: {policy.phoneNumber}
                        </p>
                      )}
                      {policy.emergencyPhone && (
                        <p className="text-sm text-blue-600 font-medium">
                          Emergencias: {policy.emergencyPhone}
                        </p>
                      )}
                      {policy.notes && (
                        <p className="text-sm text-muted-foreground mt-2">{policy.notes}</p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setPolicyToDelete(policy.id)}
                      data-testid={`button-delete-${policy.id}`}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!policyToDelete} onOpenChange={(open) => !open && setPolicyToDelete(null)}>
        <AlertDialogContent data-testid="dialog-delete-confirmation">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar póliza?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. La póliza será eliminada permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={deletePolicyMutation.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deletePolicyMutation.isPending ? "Eliminando..." : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
